package com.lite.rustchat

object RustEngine {
    init {
        System.loadLibrary("rustchat")
    }

    external fun sendChatNative(
        providerType: String,
        apiKey: String,
        model: String,
        customUrl: String,
        systemPrompt: String,
        prompt: String,
        mediaMime: String,
        mediaB64: String,
        proxyEnabled: Boolean,
        proxyUrl: String,
        proxyMode: String
    ): String
}
