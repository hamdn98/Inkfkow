package com.lite.rustchat

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

class ChatWorkerService : Service() {

    companion object {
        const val CHANNEL_ID = "rustchat_bg_channel"
        const val NOTIF_ID = 101
        const val ACTION_CHAT_UPDATED = "com.lite.rustchat.CHAT_UPDATED"
        const val EXTRA_JOB_PATH = "job_path"
    }

    private val executor = Executors.newSingleThreadExecutor()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val jobPath = intent?.getStringExtra(EXTRA_JOB_PATH)
        if (jobPath.isNullOrEmpty()) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        val notif = buildNotification("Memproses permintaan AI di background...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        executor.execute {
            var sessionId = ""
            try {
                val jobFile = File(jobPath)
                if (jobFile.exists()) {
                    val json = JSONObject(jobFile.readText())
                    jobFile.delete()

                    sessionId = json.optString("sessionId", ChatStore.getActiveSession(this).id)
                    ChatStore.setBusy(this, true, sessionId)
                    sendBroadcast(Intent(ACTION_CHAT_UPDATED).setPackage(packageName))

                    val providerType = json.optString("providerType", "gemini")
                    val apiKey = json.optString("apiKey", "")
                    val model = json.optString("model", "")
                    val customUrl = json.optString("customUrl", "")
                    val systemPrompt = json.optString("systemPrompt", "")
                    val prompt = json.optString("prompt", "")
                    val mediaMime = json.optString("mediaMime", "")
                    val mediaB64 = json.optString("mediaB64", "")
                    val proxyEnabled = json.optBoolean("proxyEnabled", false)
                    val proxyUrl = json.optString("proxyUrl", "")
                    val proxyMode = json.optString("proxyMode", "query")

                    val reply = RustEngine.sendChatNative(
                        providerType,
                        apiKey,
                        model,
                        customUrl,
                        systemPrompt,
                        prompt,
                        mediaMime,
                        mediaB64,
                        proxyEnabled,
                        proxyUrl,
                        proxyMode
                    )

                    ChatStore.appendMessageToSession(this, sessionId, ChatMsg(reply, isUser = false))
                    showDoneNotification()
                }
            } catch (e: Exception) {
                val targetId = sessionId.ifEmpty { ChatStore.getActiveSession(this).id }
                ChatStore.appendMessageToSession(
                    this,
                    targetId,
                    ChatMsg("⚠️ Gagal memproses di background: ${e.message}", isUser = false)
                )
            } finally {
                ChatStore.setBusy(this, false, "")
                sendBroadcast(Intent(ACTION_CHAT_UPDATED).setPackage(packageName))
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
            }
        }

        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "RustChat Background Engine",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Menjaga koneksi AI tetap jalan saat aplikasi ditutup"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("RustChat AI")
            .setContentText(text)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(
                PendingIntent.getActivity(
                    this,
                    0,
                    Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()

    private fun showDoneNotification() {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        val doneNotif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("RustChat AI")
            .setContentText("Balasan AI sudah siap! Ketuk untuk membuka.")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(
                PendingIntent.getActivity(
                    this,
                    1,
                    Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()
        nm.notify(102, doneNotif)
    }
}
