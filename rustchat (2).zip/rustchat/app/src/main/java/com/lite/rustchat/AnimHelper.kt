package com.lite.rustchat

import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator

object AnimHelper {
    fun attachSpringPress(view: View, enabled: Boolean = true) {
        view.setOnTouchListener { v, event ->
            if (!enabled) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.animate()
                        .scaleX(0.96f)
                        .scaleY(0.96f)
                        .alpha(0.88f)
                        .setDuration(90)
                        .start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .alpha(1f)
                        .setInterpolator(OvershootInterpolator(1.6f))
                        .setDuration(180)
                        .start()
                }
            }
            false
        }
    }

    fun animatePopIn(view: View, enabled: Boolean = true) {
        if (!enabled) return
        view.alpha = 0f
        view.scaleX = 0.93f
        view.scaleY = 0.93f
        view.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setInterpolator(OvershootInterpolator(1.1f))
            .setDuration(220)
            .start()
    }

    fun animateBubbleEntry(view: View, enabled: Boolean = true) {
        if (!enabled) return
        view.alpha = 0f
        view.translationY = 18f
        view.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(200)
            .start()
    }
}
