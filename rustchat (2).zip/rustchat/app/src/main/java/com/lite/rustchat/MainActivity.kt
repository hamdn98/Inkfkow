package com.lite.rustchat

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {

    private var attachedFileName: String = ""
    private var attachedTextContext: String = ""
    private var attachedMediaMime: String = ""
    private var attachedMediaB64: String = ""
    private var attachedRawHtml: String = ""

    private lateinit var tvHeaderTitle: TextView
    private lateinit var tvHeaderSub: TextView
    private lateinit var scrollChat: ScrollView
    private lateinit var chatContainer: LinearLayout
    private lateinit var btnQuickModel: TextView
    private lateinit var btnSend: Button
    private lateinit var attachmentChip: LinearLayout
    private lateinit var tvAttachmentName: TextView
    private lateinit var btnPreviewAttachHtml: TextView

    private val chatUpdateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            renderHistory(animateLast = true)
        }
    }

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            processPickedFile(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    200
                )
            }
        }

        tvHeaderTitle = findViewById(R.id.tvHeaderTitle)
        tvHeaderSub = findViewById(R.id.tvHeaderSub)
        val btnNewChat = findViewById<TextView>(R.id.btnNewChat)
        val btnHistory = findViewById<TextView>(R.id.btnHistory)
        val btnOpenSettings = findViewById<TextView>(R.id.btnOpenSettings)

        scrollChat = findViewById(R.id.scrollChat)
        chatContainer = findViewById(R.id.chatContainer)
        val chatInputCard = findViewById<LinearLayout>(R.id.chatInputCard)
        attachmentChip = findViewById(R.id.attachmentChip)
        tvAttachmentName = findViewById(R.id.tvAttachmentName)
        btnPreviewAttachHtml = findViewById(R.id.btnPreviewAttachHtml)
        val btnRemoveAttach = findViewById<TextView>(R.id.btnRemoveAttach)

        val etPrompt = findViewById<EditText>(R.id.etPrompt)
        val btnAttach = findViewById<TextView>(R.id.btnAttach)
        btnQuickModel = findViewById(R.id.btnQuickModel)
        btnSend = findViewById(R.id.btnSend)

        chatInputCard.background = GradientDrawable().apply {
            cornerRadius = 42f
            setColor(Color.parseColor("#16181F"))
            setStroke(2, Color.parseColor("#262934"))
        }
        btnQuickModel.background = GradientDrawable().apply {
            cornerRadius = 50f
            setColor(Color.parseColor("#1E2029"))
        }
        btnAttach.background = GradientDrawable().apply {
            cornerRadius = 50f
            setColor(Color.parseColor("#1E2029"))
        }
        btnNewChat.background = GradientDrawable().apply {
            cornerRadius = 50f
            setColor(Color.parseColor("#1E2029"))
        }
        btnHistory.background = GradientDrawable().apply {
            cornerRadius = 50f
            setColor(Color.parseColor("#1E2029"))
        }
        btnOpenSettings.background = GradientDrawable().apply {
            cornerRadius = 50f
            setColor(Color.parseColor("#1E2029"))
        }
        attachmentChip.background = GradientDrawable().apply {
            cornerRadius = 24f
            setColor(Color.parseColor("#1E2029"))
        }

        fun applyThemeAndProviderUI() {
            val active = ProviderStore.getActiveProvider(this)
            val ui = ProviderStore.getUiSettings(this)
            val proxy = ProviderStore.getProxySettings(this)
            val accent = Color.parseColor(ui.accentHex)

            val proxyTag = if (proxy.enabled) " · Proxy ON" else ""
            tvHeaderSub.text = active.subtitle() + proxyTag
            tvHeaderSub.setTextColor(accent)

            btnNewChat.setTextColor(accent)
            btnQuickModel.text = "✦ ${active.name} ▾"
            btnQuickModel.setTextColor(accent)
            btnPreviewAttachHtml.setTextColor(accent)
            btnSend.backgroundTintList = ColorStateList.valueOf(accent)

            val anim = ui.animationsEnabled
            AnimHelper.attachSpringPress(btnNewChat, anim)
            AnimHelper.attachSpringPress(btnHistory, anim)
            AnimHelper.attachSpringPress(btnOpenSettings, anim)
            AnimHelper.attachSpringPress(btnAttach, anim)
            AnimHelper.attachSpringPress(btnQuickModel, anim)
            AnimHelper.attachSpringPress(btnSend, anim)
        }
        applyThemeAndProviderUI()

        // Tombol New Chat
        btnNewChat.setOnClickListener {
            ChatStore.createNewSession(this)
            clearAttachment()
            renderHistory(animateLast = true)
            Toast.makeText(this, "Chat baru siap", Toast.LENGTH_SHORT).show()
        }

        // Tombol Riwayat Chat & Hapus
        btnHistory.setOnClickListener {
            HistoryModal.show(this) {
                renderHistory(animateLast = false)
            }
        }

        // Tombol Pengaturan (API Key, Proxy, Prompt, Tampilan)
        btnOpenSettings.setOnClickListener {
            SettingsModal.show(this) {
                applyThemeAndProviderUI()
                renderHistory(animateLast = false)
            }
        }

        btnAttach.setOnClickListener {
            filePickerLauncher.launch(arrayOf("*/*"))
        }

        btnRemoveAttach.setOnClickListener {
            clearAttachment()
        }

        btnPreviewAttachHtml.setOnClickListener {
            if (attachedRawHtml.isNotEmpty()) {
                openHtmlPreview(attachedRawHtml, attachedFileName)
            }
        }

        // Quick Switcher Provider langsung di Chatbox
        btnQuickModel.setOnClickListener {
            val ui = ProviderStore.getUiSettings(this)
            val accent = Color.parseColor(ui.accentHex)
            val providers = ProviderStore.getProviders(this)
            val active = ProviderStore.getActiveProvider(this)

            val dialog = BottomSheetDialog(this)
            val sheet = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor("#16181F"))
                setPadding(44, 38, 44, 48)
            }

            val topRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(6, 0, 6, 24)
            }

            val title = TextView(this).apply {
                text = "Pilih Provider Aktif"
                textSize = 16.5f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.parseColor("#F8FAFC"))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val btnManage = TextView(this).apply {
                text = "⚙ Kelola"
                textSize = 12.5f
                setTypeface(null, Typeface.BOLD)
                setTextColor(accent)
                setPadding(22, 10, 22, 10)
                background = GradientDrawable().apply {
                    cornerRadius = 50f
                    setColor(Color.parseColor("#1E2029"))
                }
                setOnClickListener {
                    dialog.dismiss()
                    SettingsModal.show(this@MainActivity) {
                        applyThemeAndProviderUI()
                        renderHistory(animateLast = false)
                    }
                }
            }

            topRow.addView(title)
            topRow.addView(btnManage)
            sheet.addView(topRow)

            for (item in providers) {
                val isSelected = (item.id == active.id)
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(32, 24, 32, 24)
                    background = GradientDrawable().apply {
                        cornerRadius = 28f
                        setColor(Color.parseColor("#1E2029"))
                        if (isSelected) setStroke(3, accent)
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = 14 }
                }
                AnimHelper.attachSpringPress(row, ui.animationsEnabled)

                val textCol = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }

                val tvName = TextView(this).apply {
                    text = item.name
                    textSize = 14.5f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(if (isSelected) accent else Color.parseColor("#F8FAFC"))
                }

                val tvDesc = TextView(this).apply {
                    text = item.subtitle()
                    textSize = 12f
                    setTextColor(Color.parseColor("#9CA3AF"))
                }

                textCol.addView(tvName)
                textCol.addView(tvDesc)
                row.addView(textCol)

                if (isSelected) {
                    val check = TextView(this).apply {
                        text = "AKTIF"
                        textSize = 11f
                        setTypeface(null, Typeface.BOLD)
                        setTextColor(accent)
                    }
                    row.addView(check)
                }

                row.setOnClickListener {
                    ProviderStore.setActiveId(this, item.id)
                    applyThemeAndProviderUI()
                    dialog.dismiss()
                }
                sheet.addView(row)
            }

            dialog.setContentView(sheet)
            dialog.show()
        }

        btnSend.setOnClickListener {
            val rawPrompt = etPrompt.text.toString().trim()
            if (rawPrompt.isEmpty() && attachedFileName.isEmpty()) return@setOnClickListener
            if (ChatStore.isBusy(this)) {
                Toast.makeText(this, "Tunggu balasan sebelumnya selesai ya...", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val session = ChatStore.getActiveSession(this)
            val active = ProviderStore.getActiveProvider(this)
            val ui = ProviderStore.getUiSettings(this)
            val proxy = ProviderStore.getProxySettings(this)

            // Sertakan konteks 4 pesan terakhir dari sesi aktif agar nyambung
            val recentHistory = session.messages.takeLast(4)
            val contextPrefix = if (recentHistory.isNotEmpty()) {
                buildString {
                    append("[Konteks percakapan sebelumnya]
")
                    for (h in recentHistory) {
                        val role = if (h.isUser) "User" else "Assistant"
                        append(role).append(": ").append(h.text.take(1500)).append("
")
                    }
                    append("
[Pesan terbaru]
")
                }
            } else {
                ""
            }

            val finalPrompt = buildString {
                append(contextPrefix)
                if (rawPrompt.isNotEmpty()) append(rawPrompt)
                else append("Tolong analisis file terlampir ini.")
                if (attachedTextContext.isNotEmpty()) {
                    append("

")
                    append(attachedTextContext)
                }
            }

            val userDisplay = if (rawPrompt.isNotEmpty()) rawPrompt else "Analisis file terlampir"
            val badgeText = if (attachedFileName.isNotEmpty()) "📎 $attachedFileName" else ""

            ChatStore.appendMessageToSession(
                this,
                session.id,
                ChatMsg(userDisplay, isUser = true, badge = badgeText)
            )

            val jobJson = JSONObject().apply {
                put("sessionId", session.id)
                put("providerType", active.type)
                put("apiKey", active.apiKey)
                put("model", active.model)
                put("customUrl", active.baseUrl)
                put("systemPrompt", ui.systemPrompt)
                put("prompt", finalPrompt)
                put("mediaMime", attachedMediaMime)
                put("mediaB64", attachedMediaB64)
                put("proxyEnabled", proxy.enabled)
                put("proxyUrl", proxy.proxyUrl)
                put("proxyMode", proxy.mode)
            }

            val jobFile = File(cacheDir, "job_${System.currentTimeMillis()}.json")
            jobFile.writeText(jobJson.toString())

            etPrompt.text.clear()
            clearAttachment()
            renderHistory(animateLast = true)

            val svcIntent = Intent(this, ChatWorkerService::class.java).apply {
                putExtra(ChatWorkerService.EXTRA_JOB_PATH, jobFile.absolutePath)
            }
            ContextCompat.startForegroundService(this, svcIntent)
        }

        renderHistory(animateLast = false)
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            chatUpdateReceiver,
            IntentFilter(ChatWorkerService.ACTION_CHAT_UPDATED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onResume() {
        super.onResume()
        renderHistory(animateLast = false)
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(chatUpdateReceiver)
        } catch (_: Exception) {
        }
    }

    private fun clearAttachment() {
        attachedFileName = ""
        attachedTextContext = ""
        attachedMediaMime = ""
        attachedMediaB64 = ""
        attachedRawHtml = ""
        attachmentChip.visibility = View.GONE
        btnPreviewAttachHtml.visibility = View.GONE
    }

    private fun processPickedFile(uri: Uri) {
        clearAttachment()
        val fileName = getFileName(uri)
        val mime = contentResolver.getType(uri) ?: ""
        val lower = fileName.lowercase()

        try {
            when {
                mime.startsWith("image/") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp") -> {
                    val b64 = compressImageToBase64(uri)
                    if (b64 != null) {
                        attachedFileName = fileName
                        attachedMediaMime = "image/jpeg"
                        attachedMediaB64 = b64
                        showAttachmentChip("🖼️ $fileName", showHtmlPreview = false)
                    } else {
                        Toast.makeText(this, "Gagal membaca gambar", Toast.LENGTH_SHORT).show()
                    }
                }

                mime.startsWith("video/") || lower.endsWith(".mp4") || lower.endsWith(".webm") || lower.endsWith(".mkv") -> {
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    if (bytes == null) {
                        Toast.makeText(this, "Gagal membuka video", Toast.LENGTH_SHORT).show()
                        return
                    }
                    if (bytes.size > 15 * 1024 * 1024) {
                        Toast.makeText(this, "Video maksimal 15 MB biar RAM HP aman ya", Toast.LENGTH_LONG).show()
                        return
                    }
                    attachedFileName = fileName
                    attachedMediaMime = if (mime.startsWith("video/")) mime else "video/mp4"
                    attachedMediaB64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    showAttachmentChip("🎬 $fileName (${bytes.size / 1024} KB)", showHtmlPreview = false)
                }

                lower.endsWith(".zip") || mime == "application/zip" -> {
                    val extracted = extractZipSummary(uri)
                    attachedFileName = fileName
                    attachedTextContext = extracted
                    showAttachmentChip("📦 $fileName", showHtmlPreview = false)
                }

                else -> {
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                    val text = String(bytes, Charsets.UTF_8).take(80000)
                    attachedFileName = fileName
                    attachedTextContext = "--- File: $fileName ---
$text"
                    val isHtml = lower.endsWith(".html") || lower.endsWith(".htm") || text.contains("<html", ignoreCase = true)
                    if (isHtml) attachedRawHtml = text
                    showAttachmentChip("📄 $fileName", showHtmlPreview = isHtml)
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error baca file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAttachmentChip(label: String, showHtmlPreview: Boolean) {
        tvAttachmentName.text = label
        attachmentChip.visibility = View.VISIBLE
        btnPreviewAttachHtml.visibility = if (showHtmlPreview) View.VISIBLE else View.GONE
        AnimHelper.animatePopIn(attachmentChip, ProviderStore.getUiSettings(this).animationsEnabled)
    }

    private fun getFileName(uri: Uri): String {
        var name = "lampiran"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) {
                name = cursor.getString(idx) ?: name
            }
        }
        return name
    }

    private fun compressImageToBase64(uri: Uri): String? {
        val rawBytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        val orig = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size) ?: return null
        val maxDim = 1280
        val ratio = minOf(maxDim.toFloat() / orig.width, maxDim.toFloat() / orig.height, 1f)
        val scaled = if (ratio < 1f) {
            Bitmap.createScaledBitmap(
                orig,
                (orig.width * ratio).toInt().coerceAtLeast(1),
                (orig.height * ratio).toInt().coerceAtLeast(1),
                true
            )
        } else {
            orig
        }
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun extractZipSummary(uri: Uri): String {
        val sb = StringBuilder("[Isi Arsip ZIP]
")
        var totalChars = 0
        val textExts = setOf(
            "txt", "md", "html", "htm", "css", "js", "ts", "json", "xml",
            "rs", "toml", "kt", "kts", "java", "py", "c", "cpp", "h", "yml", "yaml", "sh", "sql", "csv"
        )
        contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val name = entry.name
                        val ext = name.substringAfterLast('.', "").lowercase()
                        sb.append("• ").append(name).append(" (").append(entry.size).append(" bytes)
")
                        if (ext in textExts && totalChars < 60000) {
                            val contentBytes = zis.readBytes()
                            val contentStr = String(contentBytes, Charsets.UTF_8).take(12000)
                            sb.append("--- ").append(name).append(" ---
")
                            sb.append(contentStr).append("

")
                            totalChars += contentStr.length
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
        return sb.toString()
    }

    private fun extractHtmlCode(text: String): String? {
        val fenced = Regex("```html\s*([\s\S]*?)```", RegexOption.IGNORE_CASE).find(text)
        if (fenced != null) return fenced.groupValues[1].trim()

        val lower = text.lowercase()
        val startIdx = when {
            lower.contains("<!doctype html") -> lower.indexOf("<!doctype html")
            lower.contains("<html") -> lower.indexOf("<html")
            else -> -1
        }
        if (startIdx >= 0) {
            val endIdx = lower.lastIndexOf("</html>")
            return if (endIdx > startIdx) {
                text.substring(startIdx, endIdx + 7)
            } else {
                text.substring(startIdx)
            }
        }
        return null
    }

    private fun openHtmlPreview(htmlCode: String, titleLabel: String = "Live HTML Preview") {
        val ui = ProviderStore.getUiSettings(this)
        val accent = Color.parseColor(ui.accentHex)

        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0D0E12"))
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#16181F"))
            setPadding(32, 24, 32, 24)
        }

        val tvTitle = TextView(this).apply {
            text = "▶ $titleLabel"
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#F8FAFC"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val webView = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
        }

        val btnReload = TextView(this).apply {
            text = "↻ Reload"
            textSize = 12.5f
            setTextColor(accent)
            setPadding(20, 10, 20, 10)
            setOnClickListener {
                webView.loadDataWithBaseURL("https://localhost/", htmlCode, "text/html", "UTF-8", null)
            }
        }

        val btnClose = TextView(this).apply {
            text = "✕ Tutup"
            textSize = 12.5f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#F87171"))
            setPadding(20, 10, 12, 10)
            setOnClickListener { dialog.dismiss() }
        }

        topBar.addView(tvTitle)
        topBar.addView(btnReload)
        topBar.addView(btnClose)
        root.addView(topBar)
        root.addView(webView)

        dialog.setContentView(root)
        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT
        )
        dialog.show()

        webView.loadDataWithBaseURL("https://localhost/", htmlCode, "text/html", "UTF-8", null)
    }

    private fun renderHistory(animateLast: Boolean = false) {
        chatContainer.removeAllViews()
        val session = ChatStore.getActiveSession(this)
        val messages = session.messages
        val ui = ProviderStore.getUiSettings(this)

        if (messages.isEmpty()) {
            addBubbleView(
                ChatMsg(
                    "Halo! Sesi chat baru siap. Ketuk ⚙ untuk atur API Key & Proxy, ketuk + Baru untuk obrolan baru, atau Riwayat untuk melihat chat lama.",
                    isUser = false
                ),
                animate = animateLast
            )
        } else {
            messages.forEachIndexed { idx, msg ->
                val isLast = (idx == messages.lastIndex)
                addBubbleView(msg, animate = animateLast && isLast)
            }
        }

        val busy = ChatStore.isBusy(this)
        val busyInThisSession = busy && (ChatStore.getBusySessionId(this) == session.id)
        btnSend.isEnabled = !busy
        btnSend.text = if (busy) "..." else "Kirim"

        if (busyInThisSession) {
            val typingView = addBubbleView(
                ChatMsg("⏳ AI sedang mengetik (aman di background)...", isUser = false),
                animate = true
            )
            if (ui.animationsEnabled) {
                ObjectAnimator.ofFloat(typingView, "alpha", 0.55f, 1.0f).apply {
                    duration = 650
                    repeatMode = ValueAnimator.REVERSE
                    repeatCount = ValueAnimator.INFINITE
                    start()
                }
            }
        }

        scrollChat.post { scrollChat.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addBubbleView(msg: ChatMsg, animate: Boolean): View {
        val ui = ProviderStore.getUiSettings(this)
        val accent = Color.parseColor(ui.accentHex)

        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = if (msg.isUser) Gravity.END else Gravity.START
                bottomMargin = 24
                if (msg.isUser) marginStart = 84 else marginEnd = 84
            }
        }

        if (msg.badge.isNotEmpty()) {
            val tvBadge = TextView(this).apply {
                text = msg.badge
                textSize = 11.5f
                setTextColor(accent)
                setPadding(12, 0, 12, 6)
            }
            wrapper.addView(tvBadge)
        }

        val bubble = TextView(this).apply {
            text = msg.text
            textSize = ui.fontSizeSp
            setTextColor(if (msg.isUser) Color.parseColor("#0D0E12") else Color.parseColor("#F8FAFC"))
            setPadding(34, 24, 34, 24)
            setTextIsSelectable(true)
            background = GradientDrawable().apply {
                cornerRadius = 36f
                setColor(if (msg.isUser) accent else Color.parseColor("#1E2029"))
            }
        }
        wrapper.addView(bubble)

        if (!msg.isUser) {
            val htmlCode = extractHtmlCode(msg.text)
            val actionRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8, 10, 8, 0)
            }

            val btnCopy = TextView(this).apply {
                text = "📋 Salin"
                textSize = 11.5f
                setTextColor(Color.parseColor("#9CA3AF"))
                setPadding(18, 8, 18, 8)
                background = GradientDrawable().apply {
                    cornerRadius = 20f
                    setColor(Color.parseColor("#16181F"))
                }
                setOnClickListener {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("RustChat", msg.text))
                    Toast.makeText(this@MainActivity, "Teks disalin", Toast.LENGTH_SHORT).show()
                }
            }
            actionRow.addView(btnCopy)

            if (htmlCode != null) {
                val btnPreview = TextView(this).apply {
                    text = "▶ Preview HTML"
                    textSize = 11.5f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(Color.parseColor("#0D0E12"))
                    setPadding(22, 8, 22, 8)
                    background = GradientDrawable().apply {
                        cornerRadius = 20f
                        setColor(accent)
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { marginStart = 14 }
                    setOnClickListener {
                        openHtmlPreview(htmlCode)
                    }
                }
                actionRow.addView(btnPreview)
            }

            wrapper.addView(actionRow)
        }

        chatContainer.addView(wrapper)
        if (animate) {
            AnimHelper.animateBubbleEntry(wrapper, ui.animationsEnabled)
        }
        return wrapper
    }
}
