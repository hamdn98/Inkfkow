package com.lite.rustchat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class ChatMsg(
    val text: String,
    val isUser: Boolean,
    val badge: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class ChatSession(
    val id: String,
    var title: String,
    var updatedAt: Long,
    val messages: MutableList<ChatMsg>
)

object ChatStore {
    private const val SESSIONS_FILE = "chat_sessions_v1.json"
    private const val PREFS_STATE = "rustchat_state"
    private const val KEY_ACTIVE_SESSION = "active_session_id"
    private const val KEY_BUSY = "is_generating"
    private const val KEY_BUSY_SESSION = "busy_session_id"

    @Synchronized
    fun getAllSessions(context: Context): MutableList<ChatSession> {
        val list = mutableListOf<ChatSession>()
        val file = File(context.filesDir, SESSIONS_FILE)
        if (!file.exists()) return list
        try {
            val arr = JSONArray(file.readText())
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val msgs = mutableListOf<ChatMsg>()
                val msgArr = obj.optJSONArray("messages") ?: JSONArray()
                for (j in 0 until msgArr.length()) {
                    val m = msgArr.getJSONObject(j)
                    msgs.add(
                        ChatMsg(
                            text = m.optString("text", ""),
                            isUser = m.optBoolean("isUser", false),
                            badge = m.optString("badge", ""),
                            timestamp = m.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
                list.add(
                    ChatSession(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        title = obj.optString("title", "Chat Baru"),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis()),
                        messages = msgs
                    )
                )
            }
        } catch (_: Exception) {
        }
        list.sortByDescending { it.updatedAt }
        return list
    }

    @Synchronized
    private fun saveAllSessions(context: Context, sessions: List<ChatSession>) {
        val trimmed = sessions.sortedByDescending { it.updatedAt }.take(40)
        val arr = JSONArray()
        for (s in trimmed) {
            val msgArr = JSONArray()
            val recentMsgs = if (s.messages.size > 60) s.messages.takeLast(60) else s.messages
            for (m in recentMsgs) {
                msgArr.put(
                    JSONObject().apply {
                        put("text", m.text)
                        put("isUser", m.isUser)
                        put("badge", m.badge)
                        put("timestamp", m.timestamp)
                    }
                )
            }
            arr.put(
                JSONObject().apply {
                    put("id", s.id)
                    put("title", s.title)
                    put("updatedAt", s.updatedAt)
                    put("messages", msgArr)
                }
            )
        }
        File(context.filesDir, SESSIONS_FILE).writeText(arr.toString())
    }

    @Synchronized
    fun getActiveSession(context: Context): ChatSession {
        val sessions = getAllSessions(context)
        val prefs = context.getSharedPreferences(PREFS_STATE, Context.MODE_PRIVATE)
        val activeId = prefs.getString(KEY_ACTIVE_SESSION, null)

        val found = sessions.find { it.id == activeId }
        if (found != null) return found

        if (sessions.isNotEmpty()) {
            prefs.edit().putString(KEY_ACTIVE_SESSION, sessions[0].id).apply()
            return sessions[0]
        }

        return createNewSession(context)
    }

    @Synchronized
    fun createNewSession(context: Context): ChatSession {
        val sessions = getAllSessions(context)
        val activeId = context.getSharedPreferences(PREFS_STATE, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE_SESSION, null)
        val existingEmpty = sessions.find { it.id == activeId && it.messages.isEmpty() }
        if (existingEmpty != null) {
            existingEmpty.updatedAt = System.currentTimeMillis()
            saveAllSessions(context, sessions)
            return existingEmpty
        }

        val fresh = ChatSession(
            id = UUID.randomUUID().toString(),
            title = "Chat Baru",
            updatedAt = System.currentTimeMillis(),
            messages = mutableListOf()
        )
        sessions.add(0, fresh)
        saveAllSessions(context, sessions)
        context.getSharedPreferences(PREFS_STATE, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ACTIVE_SESSION, fresh.id)
            .apply()
        return fresh
    }

    @Synchronized
    fun switchSession(context: Context, sessionId: String) {
        context.getSharedPreferences(PREFS_STATE, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ACTIVE_SESSION, sessionId)
            .apply()
    }

    @Synchronized
    fun appendMessageToSession(context: Context, sessionId: String, msg: ChatMsg) {
        val sessions = getAllSessions(context)
        var target = sessions.find { it.id == sessionId }
        if (target == null) {
            target = ChatSession(
                id = sessionId,
                title = "Chat Baru",
                updatedAt = System.currentTimeMillis(),
                messages = mutableListOf()
            )
            sessions.add(0, target)
        }

        if (msg.isUser && (target.title == "Chat Baru" || target.messages.none { it.isUser })) {
            val cleanTitle = msg.text.replace("\n", " ").trim()
            target.title = if (cleanTitle.length > 38) cleanTitle.take(38) + "..." else cleanTitle.ifEmpty { "Lampiran File" }
        }

        target.messages.add(msg)
        target.updatedAt = System.currentTimeMillis()
        saveAllSessions(context, sessions)
    }

    @Synchronized
    fun deleteSession(context: Context, sessionId: String) {
        val sessions = getAllSessions(context)
        sessions.removeAll { it.id == sessionId }
        saveAllSessions(context, sessions)

        val prefs = context.getSharedPreferences(PREFS_STATE, Context.MODE_PRIVATE)
        if (prefs.getString(KEY_ACTIVE_SESSION, null) == sessionId) {
            if (sessions.isNotEmpty()) {
                prefs.edit().putString(KEY_ACTIVE_SESSION, sessions[0].id).apply()
            } else {
                createNewSession(context)
            }
        }
    }

    @Synchronized
    fun clearAllSessions(context: Context) {
        val file = File(context.filesDir, SESSIONS_FILE)
        if (file.exists()) file.delete()
        context.getSharedPreferences(PREFS_STATE, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_ACTIVE_SESSION)
            .apply()
        createNewSession(context)
    }

    fun setBusy(context: Context, busy: Boolean, sessionId: String = "") {
        context.getSharedPreferences(PREFS_STATE, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_BUSY, busy)
            .putString(KEY_BUSY_SESSION, if (busy) sessionId else "")
            .apply()
    }

    fun isBusy(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_STATE, Context.MODE_PRIVATE)
            .getBoolean(KEY_BUSY, false)
    }

    fun getBusySessionId(context: Context): String {
        return context.getSharedPreferences(PREFS_STATE, Context.MODE_PRIVATE)
            .getString(KEY_BUSY_SESSION, "") ?: ""
    }
}
