package com.inkflow.lite

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.dp
import java.nio.ByteBuffer

/** Seamless RGBA pattern (direct buffer so native code reads it without copying). */
class PatternDef(val name: String, val size: Int, val buffer: ByteBuffer, val preview: Color)

/** Shared state for a drag in progress (root coordinates). Primitive state holders: no boxing. */
@Stable
class DropState {
    var active by mutableStateOf(false)
    var x by mutableFloatStateOf(0f)
    var y by mutableFloatStateOf(0f)
    var color by mutableIntStateOf(0)
    var pattern by mutableStateOf<PatternDef?>(null)
}

@Stable
class ColorEditState {
    var target by mutableIntStateOf(0xFF000000.toInt())
    var newColor by mutableIntStateOf(0xFFE53935.toInt())
    var tolH by mutableFloatStateOf(0.05f)
    var tolS by mutableFloatStateOf(0.15f)
    var tolL by mutableFloatStateOf(0.15f)
    var hue by mutableFloatStateOf(0f)
    var sat by mutableFloatStateOf(0.75f)
    var value by mutableFloatStateOf(0.9f)
    var busy by mutableStateOf(false)
    var changed by mutableLongStateOf(-1L)

    fun updateNewFromHsv() {
        newColor = Color.hsv(hue, sat, value).toArgb()
    }
}

/** A swatch that can be dragged out of the panel and dropped on the canvas. */
@Composable
fun DragSource(
    drop: DropState,
    color: Int,
    pattern: PatternDef?,
    onDrop: (rootX: Float, rootY: Float) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val origin = remember { floatArrayOf(0f, 0f) }
    Box(
        modifier
            .onGloballyPositioned {
                val p = it.positionInRoot()
                origin[0] = p.x
                origin[1] = p.y
            }
            .pointerInput(color, pattern) {
                detectDragGestures(
                    onDragStart = { o: Offset ->
                        drop.color = color
                        drop.pattern = pattern
                        drop.x = origin[0] + o.x
                        drop.y = origin[1] + o.y
                        drop.active = true
                    },
                    onDrag = { change, amount ->
                        change.consume()
                        drop.x += amount.x
                        drop.y += amount.y
                    },
                    onDragEnd = {
                        drop.active = false
                        onDrop(drop.x, drop.y)
                    },
                    onDragCancel = { drop.active = false }
                )
            },
        content = content
    )
}

@Composable
private fun SwatchBox(color: Color, label: String) {
    Column {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)).background(color)
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
        )
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun ColorEditPanel(
    state: ColorEditState,
    drop: DropState,
    patterns: Array<PatternDef>,
    selecting: Boolean,
    onSelectSameColor: () -> Unit,
    onApply: () -> Unit,
    onDropColor: (rootX: Float, rootY: Float, argb: Int) -> Unit,
    onDropPattern: (rootX: Float, rootY: Float, pattern: PatternDef) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SwatchBox(Color(state.target), "Target")
            DragSource(
                drop = drop,
                color = state.newColor,
                pattern = null,
                onDrop = { x, y -> onDropColor(x, y, state.newColor) }
            ) { SwatchBox(Color(state.newColor), "New (drag)") }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (selecting) {
                    Button(onClick = onSelectSameColor, modifier = Modifier.fillMaxWidth()) { Text("Tap canvas…") }
                } else {
                    OutlinedButton(onClick = onSelectSameColor, modifier = Modifier.fillMaxWidth()) {
                        Text("Select Same Color")
                    }
                }
                Button(enabled = !state.busy, onClick = onApply, modifier = Modifier.fillMaxWidth()) {
                    Text(if (state.busy) "Replacing…" else "Replace all")
                }
            }
        }

        LabeledSlider("Hue tol", state.tolH) { state.tolH = it }
        LabeledSlider("Sat tol", state.tolS) { state.tolS = it }
        LabeledSlider("Lum tol", state.tolL) { state.tolL = it }

        LabeledSlider("New hue", state.hue / 360f) { state.hue = it * 360f; state.updateNewFromHsv() }
        LabeledSlider("New sat", state.sat) { state.sat = it; state.updateNewFromHsv() }
        LabeledSlider("New val", state.value) { state.value = it; state.updateNewFromHsv() }

        if (state.changed >= 0) Text("${state.changed} pixels changed", style = MaterialTheme.typography.labelSmall)

        Text("Patterns (drag onto canvas)", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (p in patterns) {
                DragSource(
                    drop = drop,
                    color = 0,
                    pattern = p,
                    onDrop = { x, y -> onDropPattern(x, y, p) }
                ) { SwatchBox(p.preview, p.name) }
            }
        }
    }
}

@Composable
fun LabeledSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.labelSmall, modifier = Modifier.size(width = 56.dp, height = 20.dp))
        Slider(value = value.coerceIn(0f, 1f), onValueChange = onChange, modifier = Modifier.weight(1f))
    }
}
