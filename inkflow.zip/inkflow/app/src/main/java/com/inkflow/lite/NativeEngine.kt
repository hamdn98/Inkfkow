package com.inkflow.lite

import java.nio.ByteBuffer

/** JNI facade for libinkflow_engine.so. Colours are Android ARGB ints. */
object NativeEngine {
    init {
        System.loadLibrary("inkflow_engine")
    }

    @JvmStatic external fun nativeInit(width: Int, height: Int, spillPath: String, budgetMb: Int): Int
    @JvmStatic external fun nativeRelease()
    @JvmStatic external fun nativeSetViewport(x0: Int, y0: Int, x1: Int, y1: Int)
    @JvmStatic external fun nativeRender(
        out: ByteBuffer, outW: Int, outH: Int, x0: Float, y0: Float, scale: Float, premul: Boolean
    ): Int

    @JvmStatic external fun nativeSetBrush(
        size: Float, hardness: Float, opacity: Float, flow: Float, spacing: Float,
        pressSize: Float, pressOpacity: Float, tiltSize: Float, argb: Int, blendMode: Int
    )

    @JvmStatic external fun nativeSetStabilizer(strength: Float)
    @JvmStatic external fun nativeSetSymmetry(mode: Int, count: Int, cx: Float, cy: Float)
    @JvmStatic external fun nativeSymmetryCount(): Int
    @JvmStatic external fun nativeMirrorPoint(x: Float, y: Float, index: Int): Long

    @JvmStatic external fun nativeBeginStroke(x: Float, y: Float, pressure: Float, tilt: Float)
    @JvmStatic external fun nativeMoveStroke(x: Float, y: Float, pressure: Float, tilt: Float, dt: Float)
    @JvmStatic external fun nativeEndStroke(x: Float, y: Float, pressure: Float)

    @JvmStatic external fun nativeFloodFill(x: Int, y: Int, tolerance: Int, argb: Int): Int
    @JvmStatic external fun nativeFloodPattern(
        x: Int, y: Int, tolerance: Int, pattern: ByteBuffer, pw: Int, ph: Int
    ): Int

    @JvmStatic external fun nativePickColor(x: Int, y: Int): Int
    @JvmStatic external fun nativeReplaceBegin(target: Int, newColor: Int, tolH: Float, tolS: Float, tolL: Float)
    @JvmStatic external fun nativeReplaceStep(slots: Int): Int
    @JvmStatic external fun nativeReplaceChanged(): Long

    fun unpackX(v: Long): Float = Float.fromBits((v ushr 32).toInt())
    fun unpackY(v: Long): Float = Float.fromBits(v.toInt())
}
