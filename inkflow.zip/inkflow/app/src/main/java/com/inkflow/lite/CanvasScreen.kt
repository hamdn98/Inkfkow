package com.inkflow.lite

import android.graphics.Bitmap
import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.PointerEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.min
import kotlin.math.roundToInt

enum class Tool { DRAW, FILL, PICK }

/** Pre-allocated state: nothing below is allocated per pointer event. */
@Stable
class CanvasState {
    var scale by mutableFloatStateOf(1f)
    var offX by mutableFloatStateOf(0f)
    var offY by mutableFloatStateOf(0f)
    var frame by mutableIntStateOf(0)
    var tool by mutableStateOf(Tool.DRAW)

    var size by mutableFloatStateOf(24f)
    var opacity by mutableFloatStateOf(1f)
    var stabilizer by mutableFloatStateOf(0.4f)
    var blend by mutableIntStateOf(0)
    var symmetry by mutableIntStateOf(0)
    var brushColor by mutableIntStateOf(0xFF000000.toInt())
    var fillTolerance by mutableIntStateOf(24)

    var viewW = 0
    var viewH = 0
    var bitmap: Bitmap? = null
    var buffer: ByteBuffer? = null
    val paint = Paint().apply { isFilterBitmap = false }
    var rootX = 0f
    var rootY = 0f
    var canvasRootX = 0f
    var canvasRootY = 0f
}

fun buildPatterns(): Array<PatternDef> {
    fun make(name: String, n: Int, preview: Color, pixel: (Int, Int) -> Int): PatternDef {
        val b = ByteBuffer.allocateDirect(n * n * 4)
        for (y in 0 until n) for (x in 0 until n) {
            val c = pixel(x, y)
            b.put((c shr 16).toByte()).put((c shr 8).toByte()).put(c.toByte()).put((c shr 24).toByte())
        }
        b.rewind()
        return PatternDef(name, n, b, preview)
    }
    return arrayOf(
        make("Checker", 32, Color(0xFF9E9E9E)) { x, y ->
            if ((x / 16 + y / 16) % 2 == 0) 0xFF424242.toInt() else 0xFFEEEEEE.toInt()
        },
        make("Dots", 24, Color(0xFFFFB74D)) { x, y ->
            val dx = x - 12; val dy = y - 12
            if (dx * dx + dy * dy <= 25) 0xFFEF6C00.toInt() else 0xFFFFF3E0.toInt()
        },
        make("Stripes", 16, Color(0xFF4FC3F7)) { x, y ->
            if ((x + y) % 16 < 8) 0xFF0277BD.toInt() else 0xFFE1F5FE.toInt()
        }
    )
}

private val BLEND_LABELS = arrayOf("Normal", "Multiply", "Screen", "Overlay", "Add", "Eraser")
private val SYM_LABELS = arrayOf("Off", "H", "V", "H+V", "Radial", "Mandala")

@Composable
fun CanvasScreen(width: Int, height: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val st = remember { CanvasState() }
    val ce = remember { ColorEditState() }
    val drop = remember { DropState() }
    val patterns = remember { buildPatterns() }
    var ready by remember { mutableStateOf(false) }
    var showColor by remember { mutableStateOf(false) }

    DisposableEffect(width, height) {
        val rc = NativeEngine.nativeInit(width, height, File(ctx.cacheDir, "tiles.spill").absolutePath, 160)
        ready = rc == 0
        onDispose { NativeEngine.nativeRelease() }
    }
    if (!ready) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Preparing canvas…") }
        return
    }

    fun syncViewport() {
        if (st.viewW == 0) return
        val x0 = (-st.offX / st.scale).toInt()
        val y0 = (-st.offY / st.scale).toInt()
        val x1 = ((st.viewW - st.offX) / st.scale).toInt()
        val y1 = ((st.viewH - st.offY) / st.scale).toInt()
        NativeEngine.nativeSetViewport(x0, y0, x1, y1)
    }

    fun heavy(block: () -> Unit) {
        scope.launch(Dispatchers.Default) {
            block()
            withContext(Dispatchers.Main) { st.frame++ }
        }
    }

    fun toCanvasX(sx: Float) = (sx - st.offX) / st.scale
    fun toCanvasY(sy: Float) = (sy - st.offY) / st.scale

    LaunchedEffect(st.size, st.opacity, st.blend, st.brushColor) {
        NativeEngine.nativeSetBrush(st.size, 0.7f, st.opacity, 0.8f, 0.1f, 0.6f, 0.3f, 0f, st.brushColor, st.blend)
    }
    LaunchedEffect(st.stabilizer) { NativeEngine.nativeSetStabilizer(st.stabilizer) }
    LaunchedEffect(st.symmetry) {
        NativeEngine.nativeSetSymmetry(st.symmetry, 6, width / 2f, height / 2f)
    }

    fun dropToCanvas(rootX: Float, rootY: Float, block: (Int, Int) -> Unit) {
        val cx = toCanvasX(rootX - st.canvasRootX).toInt()
        val cy = toCanvasY(rootY - st.canvasRootY).toInt()
        if (cx in 0 until width && cy in 0 until height) block(cx, cy)
    }

    Box(
        Modifier.fillMaxSize().onGloballyPositioned {
            val p = it.positionInRoot(); st.rootX = p.x; st.rootY = p.y
        }
    ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .onGloballyPositioned { val p = it.positionInRoot(); st.canvasRootX = p.x; st.canvasRootY = p.y }
                .onSizeChanged { s ->
                    if (s.width > 0 && s.height > 0 && (s.width != st.viewW || s.height != st.viewH)) {
                        st.viewW = s.width; st.viewH = s.height
                        st.bitmap = Bitmap.createBitmap(s.width, s.height, Bitmap.Config.ARGB_8888)
                        st.buffer = ByteBuffer.allocateDirect(s.width * s.height * 4)
                        val fit = min(s.width.toFloat() / width, s.height.toFloat() / height) * 0.95f
                        st.scale = fit
                        st.offX = (s.width - width * fit) / 2f
                        st.offY = (s.height - height * fit) / 2f
                        syncViewport()
                        st.frame++
                    }
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val tool = st.tool
                        var drawing = false
                        var transforming = false
                        var moved = false
                        var lastT = down.uptimeMillis
                        var lastX = toCanvasX(down.position.x)
                        var lastY = toCanvasY(down.position.y)
                        var lastP = down.pressure
                        if (tool == Tool.DRAW) {
                            NativeEngine.nativeBeginStroke(lastX, lastY, lastP, 0f)
                            drawing = true
                            st.frame++
                        }
                        var event: PointerEvent
                        do {
                            event = awaitPointerEvent()
                            val changes = event.changes
                            var pressed = 0
                            for (i in changes.indices) if (changes[i].pressed) pressed++
                            if (pressed >= 2) {
                                if (drawing) {
                                    NativeEngine.nativeEndStroke(lastX, lastY, lastP)
                                    drawing = false
                                }
                                transforming = true
                                val zoom = event.calculateZoom()
                                val pan = event.calculatePan()
                                val c = event.calculateCentroid(useCurrent = false)
                                if (zoom != 1f || pan != Offset.Zero) {
                                    val ns = (st.scale * zoom).coerceIn(0.02f, 64f)
                                    val f = ns / st.scale
                                    st.offX = c.x - (c.x - st.offX) * f + pan.x
                                    st.offY = c.y - (c.y - st.offY) * f + pan.y
                                    st.scale = ns
                                    syncViewport()
                                    st.frame++
                                }
                            } else if (!transforming && changes.isNotEmpty()) {
                                val ch = changes[0]
                                val x = toCanvasX(ch.position.x)
                                val y = toCanvasY(ch.position.y)
                                moved = true
                                if (drawing && ch.pressed) {
                                    val dt = (ch.uptimeMillis - lastT) / 1000f
                                    NativeEngine.nativeMoveStroke(x, y, ch.pressure, 0f, dt)
                                    lastT = ch.uptimeMillis
                                    st.frame++
                                }
                                lastX = x; lastY = y; lastP = ch.pressure
                            }
                            for (i in changes.indices) changes[i].consume()
                        } while (changes.any { it.pressed })

                        if (drawing) {
                            NativeEngine.nativeEndStroke(lastX, lastY, lastP)
                            st.frame++
                        } else if (!transforming) {
                            val ix = lastX.toInt()
                            val iy = lastY.toInt()
                            if (ix in 0 until width && iy in 0 until height) {
                                when (tool) {
                                    Tool.FILL -> heavy { NativeEngine.nativeFloodFill(ix, iy, st.fillTolerance, st.brushColor) }
                                    Tool.PICK -> {
                                        ce.target = NativeEngine.nativePickColor(ix, iy)
                                        st.tool = Tool.DRAW
                                    }
                                    else -> {}
                                }
                            }
                        }
                    }
                }
        ) {
            val tick = st.frame // subscribe to invalidation
            drawRect(Color(0xFF303030))
            drawRect(
                Color.White,
                topLeft = Offset(st.offX, st.offY),
                size = Size(width * st.scale, height * st.scale)
            )
            val bmp = st.bitmap
            val buf = st.buffer
            if (bmp != null && buf != null && tick >= 0) {
                NativeEngine.nativeRender(buf, bmp.width, bmp.height, -st.offX / st.scale, -st.offY / st.scale, st.scale, true)
                buf.rewind()
                bmp.copyPixelsFromBuffer(buf)
                drawIntoCanvas { it.nativeCanvas.drawBitmap(bmp, 0f, 0f, st.paint) }
            }
        }

        // Bottom controls
        Surface(
            tonalElevation = 3.dp,
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
        ) {
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = false, onClick = onBack, label = { Text("Back") })
                    FilterChip(selected = st.tool == Tool.DRAW, onClick = { st.tool = Tool.DRAW }, label = { Text("Draw") })
                    FilterChip(selected = st.tool == Tool.FILL, onClick = { st.tool = Tool.FILL }, label = { Text("Fill") })
                    FilterChip(selected = showColor, onClick = { showColor = !showColor }, label = { Text("Color edit") })
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (i in BLEND_LABELS.indices) {
                        FilterChip(selected = st.blend == i, onClick = { st.blend = i }, label = { Text(BLEND_LABELS[i]) })
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (i in SYM_LABELS.indices) {
                        FilterChip(selected = st.symmetry == i, onClick = { st.symmetry = i }, label = { Text("Sym ${SYM_LABELS[i]}") })
                    }
                }
                LabeledSlider("Size", st.size / 400f) { st.size = (it * 400f).coerceAtLeast(1f) }
                LabeledSlider("Opacity", st.opacity) { st.opacity = it }
                LabeledSlider("Streamline", st.stabilizer) { st.stabilizer = it }
                if (showColor) {
                    Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                        ColorEditPanel(
                            state = ce,
                            drop = drop,
                            patterns = patterns,
                            selecting = st.tool == Tool.PICK,
                            onSelectSameColor = { st.tool = Tool.PICK },
                            onApply = {
                                if (!ce.busy) {
                                    ce.busy = true
                                    scope.launch(Dispatchers.Default) {
                                        NativeEngine.nativeReplaceBegin(ce.target, ce.newColor, ce.tolH, ce.tolS, ce.tolL)
                                        // Chunked so drawing/rendering can interleave with the global pass.
                                        while (NativeEngine.nativeReplaceStep(64) > 0) { /* next chunk */ }
                                        val n = NativeEngine.nativeReplaceChanged()
                                        withContext(Dispatchers.Main) {
                                            ce.changed = n
                                            ce.target = ce.newColor
                                            ce.busy = false
                                            st.frame++
                                        }
                                    }
                                }
                            },
                            onDropColor = { rx, ry, argb ->
                                dropToCanvas(rx, ry) { cx, cy ->
                                    heavy { NativeEngine.nativeFloodFill(cx, cy, st.fillTolerance, argb) }
                                }
                            },
                            onDropPattern = { rx, ry, p ->
                                dropToCanvas(rx, ry) { cx, cy ->
                                    heavy { NativeEngine.nativeFloodPattern(cx, cy, st.fillTolerance, p.buffer, p.size, p.size) }
                                }
                            }
                        )
                    }
                }
            }
        }

        // Drag ghost
        if (drop.active) {
            val ghost = drop.pattern?.preview ?: Color(drop.color)
            Box(
                Modifier
                    .offset { IntOffset((drop.x - st.rootX - 24f).roundToInt(), (drop.y - st.rootY - 24f).roundToInt()) }
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(ghost.copy(alpha = 0.85f))
            )
        }
    }
}
