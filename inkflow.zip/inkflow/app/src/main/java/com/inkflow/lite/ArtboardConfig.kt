package com.inkflow.lite

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

object ArtboardLimits {
    const val MIN = 16
    const val MAX = 16384
}

/** Returns the parsed dimension or null when empty / not a number / outside 16..16384. */
fun validateDimension(text: String): Int? {
    if (text.isEmpty() || text.length > 5) return null
    var v = 0
    for (i in text.indices) {
        val d = text[i] - '0'
        if (d !in 0..9) return null
        v = v * 10 + d
    }
    return if (v in ArtboardLimits.MIN..ArtboardLimits.MAX) v else null
}

private class Preset(val label: String, val w: Int, val h: Int)

private val PRESETS = arrayOf(
    Preset("HD 1080×1920", 1080, 1920),
    Preset("Square 2048", 2048, 2048),
    Preset("A4 300dpi 2480×3508", 2480, 3508),
    Preset("4K 4096", 4096, 4096),
    Preset("8K 8192", 8192, 8192),
    Preset("16K 16384", 16384, 16384),
)

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun ArtboardConfigScreen(onCreate: (width: Int, height: Int) -> Unit) {
    var wText by remember { mutableStateOf("2048") }
    var hText by remember { mutableStateOf("2048") }
    val w = validateDimension(wText)
    val h = validateDimension(hText)
    val valid = w != null && h != null

    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("New artboard", style = MaterialTheme.typography.headlineSmall)

        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (p in PRESETS) {
                AssistChip(onClick = { wText = p.w.toString(); hText = p.h.toString() }, label = { Text(p.label) })
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = wText,
                onValueChange = { if (it.length <= 5) wText = it.filter(Char::isDigit) },
                label = { Text("Width px") },
                isError = w == null,
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = hText,
                onValueChange = { if (it.length <= 5) hText = it.filter(Char::isDigit) },
                label = { Text("Height px") },
                isError = h == null,
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
        }

        if (!valid) {
            Text(
                "Size must be between ${ArtboardLimits.MIN} and ${ArtboardLimits.MAX} px.",
                color = MaterialTheme.colorScheme.error
            )
        } else {
            val megapixels = w!!.toLong() * h!!.toLong() / 1_000_000L
            val virtualMb = w.toLong() * h.toLong() * 4L / (1024L * 1024L)
            Text(
                "$megapixels MP. Virtual size $virtualMb MB; only painted 256×256 tiles use RAM, " +
                    "the rest is spilled to cache storage."
            )
        }

        Button(enabled = valid, onClick = { onCreate(w!!, h!!) }, modifier = Modifier.fillMaxWidth()) {
            Text("Create")
        }
    }
}
