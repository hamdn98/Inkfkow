package com.inkflow.lite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var w by remember { mutableIntStateOf(0) }
                    var h by remember { mutableIntStateOf(0) }
                    if (w == 0) {
                        ArtboardConfigScreen { nw, nh -> w = nw; h = nh }
                    } else {
                        BackHandler { w = 0; h = 0 }
                        CanvasScreen(width = w, height = h, onBack = { w = 0; h = 0 })
                    }
                }
            }
        }
    }
}
