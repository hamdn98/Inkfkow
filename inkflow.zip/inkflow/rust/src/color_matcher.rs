//! HSL "Select & Edit Same Color" matcher. Works on one 256x256 RGBA tile at a time,
//! so the same matcher is applied to every tile (resident or spilled) and boundaries
//! between tiles never need special handling.

#[derive(Clone, Copy)]
pub struct ColorMatcher {
    th: f32,
    ts: f32,
    tl: f32,
    tol_h: f32, // 0..1, 1 = any hue
    tol_s: f32,
    tol_l: f32,
    new_rgb: [u8; 3],
}

#[inline]
pub fn rgb_to_hsl(r: u8, g: u8, b: u8) -> (f32, f32, f32) {
    let rf = r as f32 / 255.0;
    let gf = g as f32 / 255.0;
    let bf = b as f32 / 255.0;
    let max = rf.max(gf).max(bf);
    let min = rf.min(gf).min(bf);
    let l = (max + min) * 0.5;
    let d = max - min;
    if d < 1e-6 {
        return (0.0, 0.0, l);
    }
    let s = d / (1.0 - (2.0 * l - 1.0).abs()).max(1e-6);
    let h = if max == rf {
        ((gf - bf) / d).rem_euclid(6.0)
    } else if max == gf {
        (bf - rf) / d + 2.0
    } else {
        (rf - gf) / d + 4.0
    };
    (h / 6.0, s.min(1.0), l)
}

impl ColorMatcher {
    pub fn new(target: [u8; 4], new_color: [u8; 4], tol_h: f32, tol_s: f32, tol_l: f32) -> Self {
        let (th, ts, tl) = rgb_to_hsl(target[0], target[1], target[2]);
        Self {
            th,
            ts,
            tl,
            tol_h: tol_h.clamp(0.0, 1.0),
            tol_s: tol_s.clamp(0.0, 1.0),
            tol_l: tol_l.clamp(0.0, 1.0),
            new_rgb: [new_color[0], new_color[1], new_color[2]],
        }
    }

    #[inline]
    pub fn matches(&self, rgb: [u8; 3]) -> bool {
        let (h, s, l) = rgb_to_hsl(rgb[0], rgb[1], rgb[2]);
        if (l - self.tl).abs() > self.tol_l || (s - self.ts).abs() > self.tol_s {
            return false;
        }
        // Hue is meaningless for near-grey colours.
        if s < 0.04 && self.ts < 0.04 {
            return true;
        }
        let dh = (h - self.th).abs();
        let dh = dh.min(1.0 - dh) * 2.0; // normalised 0..1
        dh <= self.tol_h
    }

    /// Replaces matching pixels in one tile. Returns number of pixels changed.
    /// A one-entry cache skips HSL conversion for runs of identical colours.
    pub fn replace_in_tile(&self, tile: &mut [u8]) -> u32 {
        let mut count = 0u32;
        let mut last = [0u8; 3];
        let mut last_hit = false;
        let mut have = false;
        for px in tile.chunks_exact_mut(4) {
            if px[3] == 0 {
                continue;
            }
            let rgb = [px[0], px[1], px[2]];
            let hit = if have && rgb == last {
                last_hit
            } else {
                let h = self.matches(rgb);
                last = rgb;
                last_hit = h;
                have = true;
                h
            };
            if hit {
                px[0] = self.new_rgb[0];
                px[1] = self.new_rgb[1];
                px[2] = self.new_rgb[2];
                count += 1;
            }
        }
        count
    }
}
