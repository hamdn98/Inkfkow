//! Sparse tile-based virtual canvas (up to 16384x16384).
//! Pixels are straight-alpha RGBA8. Tiles are 256x256 and allocated lazily.
//! Tiles outside the viewport are spilled (LRU) to a sparse file when the
//! resident budget is exceeded, and reloaded on demand.

use std::fs::{File, OpenOptions};
use std::os::unix::fs::FileExt;

pub const TILE: usize = 256;
pub const TILE_BYTES: usize = TILE * TILE * 4;
pub const MAX_DIM: u32 = 16384;

#[derive(Default)]
struct Slot {
    data: Option<Box<[u8]>>,
    on_disk: bool,
    dirty: bool,
    stamp: u64,
}

pub struct VirtualCanvas16K {
    pub width: u32,
    pub height: u32,
    pub tiles_x: u32,
    pub tiles_y: u32,
    slots: Vec<Slot>,
    spill: Option<File>,
    scratch: Box<[u8]>,
    pool: Vec<Box<[u8]>>,
    resident: usize,
    budget: usize,
    clock: u64,
    keep: (u32, u32, u32, u32), // protected viewport tile range (inclusive)
}

impl VirtualCanvas16K {
    pub fn new(
        width: u32,
        height: u32,
        spill_path: Option<&str>,
        budget_tiles: usize,
    ) -> Result<Self, i32> {
        if width == 0 || height == 0 || width > MAX_DIM || height > MAX_DIM {
            return Err(-1);
        }
        let tiles_x = (width + 255) / 256;
        let tiles_y = (height + 255) / 256;
        let spill = match spill_path {
            Some(p) => Some(
                OpenOptions::new()
                    .read(true)
                    .write(true)
                    .create(true)
                    .truncate(true)
                    .open(p)
                    .map_err(|_| -2)?,
            ),
            None => None,
        };
        let mut slots = Vec::new();
        slots.resize_with((tiles_x * tiles_y) as usize, Slot::default);
        Ok(Self {
            width,
            height,
            tiles_x,
            tiles_y,
            slots,
            spill,
            scratch: vec![0u8; TILE_BYTES].into_boxed_slice(),
            pool: Vec::with_capacity(8),
            resident: 0,
            budget: budget_tiles.max(16),
            clock: 0,
            keep: (0, 0, 0, 0),
        })
    }

    #[inline]
    fn idx(&self, tx: u32, ty: u32) -> usize {
        (ty * self.tiles_x + tx) as usize
    }

    pub fn slot_count(&self) -> usize {
        self.slots.len()
    }

    pub fn resident_tiles(&self) -> usize {
        self.resident
    }

    /// Declares the visible pixel rect; tiles inside are never evicted.
    pub fn set_viewport(&mut self, x0: i32, y0: i32, x1: i32, y1: i32) {
        let tx0 = (x0.max(0) as u32 / 256).min(self.tiles_x - 1);
        let ty0 = (y0.max(0) as u32 / 256).min(self.tiles_y - 1);
        let tx1 = (x1.max(0) as u32 / 256).min(self.tiles_x - 1);
        let ty1 = (y1.max(0) as u32 / 256).min(self.tiles_y - 1);
        self.keep = (tx0, ty0, tx1.max(tx0), ty1.max(ty0));
        self.trim(usize::MAX);
    }

    fn load(&mut self, i: usize) {
        if self.slots[i].data.is_some() {
            return;
        }
        let mut buf = self
            .pool
            .pop()
            .unwrap_or_else(|| vec![0u8; TILE_BYTES].into_boxed_slice());
        let mut from_disk = false;
        if self.slots[i].on_disk {
            if let Some(f) = &self.spill {
                from_disk = f
                    .read_exact_at(&mut buf, i as u64 * TILE_BYTES as u64)
                    .is_ok();
            }
        }
        if !from_disk {
            buf.fill(0);
        }
        let s = &mut self.slots[i];
        s.data = Some(buf);
        s.dirty = !from_disk;
        self.resident += 1;
        self.trim(i);
    }

    fn evict(&mut self, i: usize) -> bool {
        let off = i as u64 * TILE_BYTES as u64;
        if self.slots[i].dirty {
            let empty = self.slots[i]
                .data
                .as_ref()
                .map(|b| b.iter().all(|&v| v == 0))
                .unwrap_or(true);
            if empty {
                self.slots[i].on_disk = false;
            } else {
                let ok = match (&self.spill, &self.slots[i].data) {
                    (Some(f), Some(b)) => f.write_all_at(b, off).is_ok(),
                    _ => false,
                };
                if !ok {
                    return false;
                }
                self.slots[i].on_disk = true;
            }
        }
        let buf = self.slots[i].data.take();
        self.slots[i].dirty = false;
        self.resident -= 1;
        if let Some(b) = buf {
            if self.pool.len() < 8 {
                self.pool.push(b);
            }
        }
        true
    }

    fn trim(&mut self, just: usize) {
        if self.spill.is_none() {
            return;
        }
        while self.resident > self.budget {
            let mut best = usize::MAX;
            let mut best_stamp = u64::MAX;
            for (i, s) in self.slots.iter().enumerate() {
                if i == just || s.data.is_none() || s.stamp >= best_stamp {
                    continue;
                }
                let tx = i as u32 % self.tiles_x;
                let ty = i as u32 / self.tiles_x;
                if tx >= self.keep.0 && tx <= self.keep.2 && ty >= self.keep.1 && ty <= self.keep.3 {
                    continue;
                }
                best = i;
                best_stamp = s.stamp;
            }
            if best == usize::MAX || !self.evict(best) {
                break;
            }
        }
    }

    /// Writable tile (allocated / reloaded on demand, marked dirty).
    pub fn tile_mut(&mut self, tx: u32, ty: u32) -> &mut [u8] {
        let i = self.idx(tx, ty);
        self.load(i);
        self.clock += 1;
        let clock = self.clock;
        let s = &mut self.slots[i];
        s.stamp = clock;
        s.dirty = true;
        s.data.as_mut().unwrap()
    }

    /// Read-only tile; None when the tile is still fully transparent.
    pub fn tile_ref(&mut self, tx: u32, ty: u32) -> Option<&[u8]> {
        let i = self.idx(tx, ty);
        if self.slots[i].data.is_none() && !self.slots[i].on_disk {
            return None;
        }
        self.load(i);
        self.clock += 1;
        let clock = self.clock;
        let s = &mut self.slots[i];
        s.stamp = clock;
        s.data.as_deref()
    }

    pub fn get_pixel(&mut self, x: u32, y: u32) -> [u8; 4] {
        if x >= self.width || y >= self.height {
            return [0; 4];
        }
        match self.tile_ref(x / 256, y / 256) {
            None => [0; 4],
            Some(t) => {
                let o = (((y % 256) * 256 + (x % 256)) * 4) as usize;
                [t[o], t[o + 1], t[o + 2], t[o + 3]]
            }
        }
    }

    pub fn set_pixel(&mut self, x: u32, y: u32, c: [u8; 4]) {
        if x >= self.width || y >= self.height {
            return;
        }
        let t = self.tile_mut(x / 256, y / 256);
        let o = (((y % 256) * 256 + (x % 256)) * 4) as usize;
        t[o..o + 4].copy_from_slice(&c);
    }

    /// Visits slots [start, end): resident tiles in place, spilled tiles through
    /// a scratch buffer (no residency growth). `f` returns true if it changed data.
    pub fn for_each_tile_range<F: FnMut(&mut [u8]) -> bool>(
        &mut self,
        start: usize,
        end: usize,
        mut f: F,
    ) {
        let end = end.min(self.slots.len());
        let Self { slots, spill, scratch, .. } = self;
        for i in start..end {
            let slot = &mut slots[i];
            if let Some(d) = slot.data.as_mut() {
                if f(d) {
                    slot.dirty = true;
                }
            } else if slot.on_disk {
                if let Some(file) = spill.as_ref() {
                    let off = i as u64 * TILE_BYTES as u64;
                    if file.read_exact_at(scratch, off).is_ok() && f(scratch) {
                        let _ = file.write_all_at(scratch, off);
                    }
                }
            }
        }
    }

    /// Nearest-neighbour render of the visible area into a caller-owned RGBA buffer
    /// (ow*oh*4 bytes). `x0,y0` = canvas coords at output pixel (0,0); `scale` = output px per canvas px.
    /// Zero heap allocation.
    pub fn render(
        &mut self,
        out: &mut [u8],
        ow: u32,
        oh: u32,
        x0: f32,
        y0: f32,
        scale: f32,
        premul: bool,
    ) {
        out.fill(0);
        let inv = 1.0 / scale;
        let cw = self.width as f32;
        let ch = self.height as f32;
        let ox_lo = (((-x0) * scale - 0.5).ceil().max(0.0)) as i64;
        let ox_hi = (((cw - x0) * scale - 0.5).ceil().min(ow as f32)) as i64;
        let maxx = self.width as i64 - 1;
        for oy in 0..oh {
            let syf = ((oy as f32 + 0.5) * inv + y0).floor();
            if syf < 0.0 || syf >= ch {
                continue;
            }
            let sy = syf as u32;
            let ty = sy / 256;
            let ly = (sy % 256) as usize;
            let mut ox = ox_lo;
            while ox < ox_hi {
                let sx = (((ox as f32 + 0.5) * inv + x0).floor() as i64).clamp(0, maxx);
                let tx = (sx / 256) as u32;
                let run_end = ((((tx as f32 + 1.0) * 256.0 - x0) * scale - 0.5).ceil() as i64)
                    .max(ox + 1)
                    .min(ox_hi);
                if let Some(tile) = self.tile_ref(tx, ty) {
                    let base = tx as i64 * 256;
                    for o in ox..run_end {
                        let sxa = (((o as f32 + 0.5) * inv + x0).floor() as i64).clamp(0, maxx);
                        let lx = (sxa - base).clamp(0, 255) as usize;
                        let si = (ly * 256 + lx) * 4;
                        let di = ((oy as usize) * ow as usize + o as usize) * 4;
                        let a = tile[si + 3] as u32;
                        if a == 0 {
                            continue;
                        }
                        if premul && a < 255 {
                            out[di] = ((tile[si] as u32 * a + 127) / 255) as u8;
                            out[di + 1] = ((tile[si + 1] as u32 * a + 127) / 255) as u8;
                            out[di + 2] = ((tile[si + 2] as u32 * a + 127) / 255) as u8;
                        } else {
                            out[di] = tile[si];
                            out[di + 1] = tile[si + 1];
                            out[di + 2] = tile[si + 2];
                        }
                        out[di + 3] = a as u8;
                    }
                }
                ox = run_end;
            }
        }
    }
}
