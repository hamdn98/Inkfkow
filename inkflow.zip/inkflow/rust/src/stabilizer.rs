//! Procreate-style "Streamline": a critically-damped spring chases the raw pointer,
//! then a short moving average polishes the path. Fixed-size state, zero allocation.

const MAXW: usize = 16;

pub struct Stabilizer {
    strength: f32,
    px: f32,
    py: f32,
    vx: f32,
    vy: f32,
    ring: [[f32; 2]; MAXW],
    head: usize,
    filled: usize,
    win: usize,
}

impl Stabilizer {
    pub const fn new() -> Self {
        Self {
            strength: 0.5,
            px: 0.0,
            py: 0.0,
            vx: 0.0,
            vy: 0.0,
            ring: [[0.0; 2]; MAXW],
            head: 0,
            filled: 0,
            win: 4,
        }
    }

    pub fn set_strength(&mut self, s: f32) {
        let s = s.clamp(0.0, 1.0);
        self.strength = s;
        self.win = 1 + (s * (MAXW as f32 - 1.0) * 0.5) as usize;
    }

    fn push(&mut self, x: f32, y: f32) {
        self.ring[self.head] = [x, y];
        self.head = (self.head + 1) % MAXW;
        if self.filled < MAXW {
            self.filled += 1;
        }
    }

    fn average(&self) -> (f32, f32) {
        let n = self.win.min(self.filled).max(1);
        let mut sx = 0.0;
        let mut sy = 0.0;
        for k in 0..n {
            let i = (self.head + MAXW - 1 - k) % MAXW;
            sx += self.ring[i][0];
            sy += self.ring[i][1];
        }
        (sx / n as f32, sy / n as f32)
    }

    pub fn begin(&mut self, x: f32, y: f32) {
        self.px = x;
        self.py = y;
        self.vx = 0.0;
        self.vy = 0.0;
        self.head = 0;
        self.filled = 0;
        self.push(x, y);
    }

    /// Feed a raw pointer sample; returns the stabilised position.
    pub fn update(&mut self, tx: f32, ty: f32, dt: f32) -> (f32, f32) {
        if self.strength <= 0.001 {
            self.px = tx;
            self.py = ty;
            self.push(tx, ty);
            return (tx, ty);
        }
        let dt = dt.clamp(0.001, 0.05);
        let k = 1400.0 - 1360.0 * self.strength; // stiffness: strong smoothing = soft spring
        let c = 2.0 * 0.95 * k.sqrt(); // near critical damping
        let h = dt * 0.25;
        for _ in 0..4 {
            let ax = k * (tx - self.px) - c * self.vx;
            let ay = k * (ty - self.py) - c * self.vy;
            self.vx += ax * h;
            self.vy += ay * h;
            self.px += self.vx * h;
            self.py += self.vy * h;
        }
        self.push(self.px, self.py);
        self.average()
    }

    /// Pen lifted: snap to the final raw target so the stroke ends where the finger did.
    pub fn end(&mut self, tx: f32, ty: f32) -> (f32, f32) {
        self.px = tx;
        self.py = ty;
        self.vx = 0.0;
        self.vy = 0.0;
        (tx, ty)
    }
}
