//! Engine core: brush dynamics, blend modes, scanline flood fill, symmetry, JNI bindings.
//! Colours crossing JNI are Android ARGB ints. Pixels in the canvas are straight RGBA8.

use crate::color_matcher::ColorMatcher;
use crate::stabilizer::Stabilizer;
use crate::tiled_canvas::{VirtualCanvas16K, TILE, TILE_BYTES};
use jni::objects::{JByteBuffer, JClass, JString};
use jni::sys::{jboolean, jfloat, jint, jlong};
use jni::JNIEnv;
use std::sync::Mutex;

// ───────────────────────── Blend modes ─────────────────────────

#[derive(Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum BlendMode {
    Normal = 0,
    Multiply = 1,
    Screen = 2,
    Overlay = 3,
    Add = 4,
    Eraser = 5,
}

impl BlendMode {
    pub fn from_i32(v: i32) -> Self {
        match v {
            1 => Self::Multiply,
            2 => Self::Screen,
            3 => Self::Overlay,
            4 => Self::Add,
            5 => Self::Eraser,
            _ => Self::Normal,
        }
    }
}

#[inline(always)]
fn channel(mode: BlendMode, s: f32, d: f32) -> f32 {
    match mode {
        BlendMode::Normal | BlendMode::Eraser => s,
        BlendMode::Multiply => s * d,
        BlendMode::Screen => s + d - s * d,
        BlendMode::Overlay => {
            if d <= 0.5 {
                2.0 * s * d
            } else {
                1.0 - 2.0 * (1.0 - s) * (1.0 - d)
            }
        }
        BlendMode::Add => (s + d).min(1.0),
    }
}

/// W3C-style compositing on straight-alpha RGBA8. `s*` are 0..1, `sa` is source coverage*alpha.
#[inline(always)]
pub fn blend_px(d: &mut [u8], sr: f32, sg: f32, sb: f32, sa: f32, mode: BlendMode) {
    let da = d[3] as f32 * (1.0 / 255.0);
    if mode == BlendMode::Eraser {
        d[3] = ((da * (1.0 - sa)) * 255.0 + 0.5) as u8;
        return;
    }
    if da <= 0.0 {
        d[0] = (sr * 255.0 + 0.5) as u8;
        d[1] = (sg * 255.0 + 0.5) as u8;
        d[2] = (sb * 255.0 + 0.5) as u8;
        d[3] = (sa * 255.0 + 0.5) as u8;
        return;
    }
    let dr = d[0] as f32 * (1.0 / 255.0);
    let dg = d[1] as f32 * (1.0 / 255.0);
    let db = d[2] as f32 * (1.0 / 255.0);
    let br = channel(mode, sr, dr);
    let bg = channel(mode, sg, dg);
    let bb = channel(mode, sb, db);
    let ao = sa + da * (1.0 - sa);
    let k1 = (1.0 - sa) * da;
    let k2 = sa * (1.0 - da);
    let k3 = sa * da;
    let inv = 1.0 / ao;
    d[0] = (((k1 * dr + k2 * sr + k3 * br) * inv).min(1.0) * 255.0 + 0.5) as u8;
    d[1] = (((k1 * dg + k2 * sg + k3 * bg) * inv).min(1.0) * 255.0 + 0.5) as u8;
    d[2] = (((k1 * db + k2 * sb + k3 * bb) * inv).min(1.0) * 255.0 + 0.5) as u8;
    d[3] = (ao.min(1.0) * 255.0 + 0.5) as u8;
}

// ───────────────────────── Symmetry ─────────────────────────

pub const MAX_SYM: usize = 32;

#[inline]
pub fn pack(x: f32, y: f32) -> u64 {
    ((x.to_bits() as u64) << 32) | y.to_bits() as u64
}

#[inline]
pub fn unpack(v: u64) -> (f32, f32) {
    (f32::from_bits((v >> 32) as u32), f32::from_bits(v as u32))
}

/// mode: 0 off, 1 horizontal (mirror left/right), 2 vertical (mirror top/bottom),
/// 3 both, 4 radial, 5 mandala (radial + mirror).
#[derive(Clone, Copy)]
pub struct Symmetry {
    pub mode: u8,
    pub count: u8,
    pub cx: f32,
    pub cy: f32,
    rot: [[f32; 2]; 16],
}

impl Symmetry {
    pub const fn new() -> Self {
        Self { mode: 0, count: 6, cx: 0.0, cy: 0.0, rot: [[1.0, 0.0]; 16] }
    }

    pub fn set(&mut self, mode: u8, count: u8, cx: f32, cy: f32) {
        self.mode = mode;
        self.count = count.clamp(2, 16);
        self.cx = cx;
        self.cy = cy;
        for k in 0..self.count as usize {
            let a = core::f32::consts::TAU * k as f32 / self.count as f32;
            let (s, c) = a.sin_cos();
            self.rot[k] = [c, s];
        }
    }

    /// Writes packed (x,y) f32 pairs into `out`; returns how many.
    pub fn points(&self, x: f32, y: f32, out: &mut [u64; MAX_SYM]) -> usize {
        let mx = 2.0 * self.cx - x;
        let my = 2.0 * self.cy - y;
        match self.mode {
            1 => {
                out[0] = pack(x, y);
                out[1] = pack(mx, y);
                2
            }
            2 => {
                out[0] = pack(x, y);
                out[1] = pack(x, my);
                2
            }
            3 => {
                out[0] = pack(x, y);
                out[1] = pack(mx, y);
                out[2] = pack(x, my);
                out[3] = pack(mx, my);
                4
            }
            4 | 5 => {
                let n = self.count as usize;
                let mut w = 0;
                for k in 0..n {
                    let [c, s] = self.rot[k];
                    let dx = x - self.cx;
                    let dy = y - self.cy;
                    out[w] = pack(self.cx + dx * c - dy * s, self.cy + dx * s + dy * c);
                    w += 1;
                    if self.mode == 5 {
                        let dx = mx - self.cx;
                        out[w] = pack(self.cx + dx * c - dy * s, self.cy + dx * s + dy * c);
                        w += 1;
                    }
                }
                w
            }
            _ => {
                out[0] = pack(x, y);
                1
            }
        }
    }
}

// ───────────────────────── Brush ─────────────────────────

#[derive(Clone, Copy)]
pub struct Brush {
    pub size: f32, // diameter in canvas px
    pub hardness: f32,
    pub opacity: f32,
    pub flow: f32,
    pub spacing: f32, // fraction of diameter
    pub press_size: f32,
    pub press_opacity: f32,
    pub tilt_size: f32,
    pub color: [u8; 4],
    pub mode: BlendMode,
}

impl Brush {
    pub const fn new() -> Self {
        Self {
            size: 24.0,
            hardness: 0.7,
            opacity: 1.0,
            flow: 0.8,
            spacing: 0.1,
            press_size: 0.6,
            press_opacity: 0.3,
            tilt_size: 0.0,
            color: [0, 0, 0, 255],
            mode: BlendMode::Normal,
        }
    }
}

fn dab(c: &mut VirtualCanvas16K, b: &Brush, cx: f32, cy: f32, r: f32, alpha: f32) {
    let x0 = ((cx - r).floor() as i32).max(0);
    let y0 = ((cy - r).floor() as i32).max(0);
    let x1 = ((cx + r).ceil() as i32).min(c.width as i32 - 1);
    let y1 = ((cy + r).ceil() as i32).min(c.height as i32 - 1);
    if x1 < x0 || y1 < y0 {
        return;
    }
    let inner = r * b.hardness.clamp(0.0, 0.99);
    let inv = 1.0 / (r - inner).max(0.001);
    let sr = b.color[0] as f32 / 255.0;
    let sg = b.color[1] as f32 / 255.0;
    let sb = b.color[2] as f32 / 255.0;
    let ca = if b.mode == BlendMode::Eraser { 1.0 } else { b.color[3] as f32 / 255.0 };
    let mode = b.mode;
    for ty in (y0 as u32 / 256)..=(y1 as u32 / 256) {
        for tx in (x0 as u32 / 256)..=(x1 as u32 / 256) {
            let tile = c.tile_mut(tx, ty);
            let bx = (tx * 256) as i32;
            let by = (ty * 256) as i32;
            for py in y0.max(by)..=y1.min(by + 255) {
                let dy = py as f32 + 0.5 - cy;
                for px in x0.max(bx)..=x1.min(bx + 255) {
                    let dx = px as f32 + 0.5 - cx;
                    let d = (dx * dx + dy * dy).sqrt();
                    if d >= r {
                        continue;
                    }
                    let cov = if d <= inner {
                        1.0
                    } else {
                        let t = (r - d) * inv;
                        t * t * (3.0 - 2.0 * t)
                    };
                    let sa = cov * alpha * ca;
                    if sa <= 0.0 {
                        continue;
                    }
                    let o = (((py - by) * 256 + (px - bx)) * 4) as usize;
                    blend_px(&mut tile[o..o + 4], sr, sg, sb, sa, mode);
                }
            }
        }
    }
}

fn stamp(c: &mut VirtualCanvas16K, b: &Brush, sym: &Symmetry, x: f32, y: f32, pressure: f32, tilt: f32) {
    let p = pressure.clamp(0.0, 1.0);
    let r = (b.size * 0.5 * (1.0 - b.press_size + b.press_size * p) * (1.0 + b.tilt_size * tilt.clamp(0.0, 1.0)))
        .max(0.5);
    let a = (b.opacity * b.flow * (1.0 - b.press_opacity + b.press_opacity * p)).clamp(0.0, 1.0);
    let mut pts = [0u64; MAX_SYM];
    let n = sym.points(x, y, &mut pts);
    for i in 0..n {
        let (px, py) = unpack(pts[i]);
        dab(c, b, px, py, r, a);
    }
}

// ───────────────────────── Engine ─────────────────────────

struct StrokeState {
    active: bool,
    last_mid: [f32; 2],
    last_pt: [f32; 2],
    last_p: f32,
    tilt: f32,
    carry: f32,
}

struct ReplaceJob {
    m: ColorMatcher,
    cursor: usize,
    changed: u64,
}

pub struct Engine {
    pub canvas: VirtualCanvas16K,
    pub brush: Brush,
    pub sym: Symmetry,
    pub stab: Stabilizer,
    st: StrokeState,
    stack: Vec<(u32, u32)>,
    job: Option<ReplaceJob>,
}

#[inline]
fn near(a: [u8; 4], b: [u8; 4], tol: u8) -> bool {
    a[0].abs_diff(b[0]) <= tol && a[1].abs_diff(b[1]) <= tol && a[2].abs_diff(b[2]) <= tol && a[3].abs_diff(b[3]) <= tol
}

impl Engine {
    pub fn new(canvas: VirtualCanvas16K) -> Self {
        let (cx, cy) = (canvas.width as f32 * 0.5, canvas.height as f32 * 0.5);
        let mut sym = Symmetry::new();
        sym.set(0, 6, cx, cy);
        Self {
            canvas,
            brush: Brush::new(),
            sym,
            stab: Stabilizer::new(),
            st: StrokeState { active: false, last_mid: [0.0; 2], last_pt: [0.0; 2], last_p: 1.0, tilt: 0.0, carry: 0.0 },
            stack: Vec::with_capacity(4096),
            job: None,
        }
    }

    #[inline]
    fn step(&self) -> f32 {
        (self.brush.size * self.brush.spacing).max(0.75)
    }

    pub fn begin_stroke(&mut self, x: f32, y: f32, p: f32, tilt: f32) {
        self.stab.begin(x, y);
        self.st = StrokeState { active: true, last_mid: [x, y], last_pt: [x, y], last_p: p, tilt, carry: 0.0 };
        stamp(&mut self.canvas, &self.brush, &self.sym, x, y, p, tilt);
        self.st.carry = self.step();
    }

    pub fn move_stroke(&mut self, x: f32, y: f32, p: f32, tilt: f32, dt: f32) {
        if !self.st.active {
            return;
        }
        let (sx, sy) = self.stab.update(x, y, dt);
        let mid = [(self.st.last_pt[0] + sx) * 0.5, (self.st.last_pt[1] + sy) * 0.5];
        self.st.tilt = tilt;
        self.quad(self.st.last_mid, self.st.last_pt, mid, self.st.last_p, p);
        self.st.last_mid = mid;
        self.st.last_pt = [sx, sy];
        self.st.last_p = p;
    }

    pub fn end_stroke(&mut self, x: f32, y: f32, p: f32) {
        if !self.st.active {
            return;
        }
        let (ex, ey) = self.stab.end(x, y);
        self.quad(self.st.last_mid, self.st.last_pt, [ex, ey], self.st.last_p, p);
        self.st.active = false;
    }

    /// Quadratic Bézier (midpoint spline) sampled by arc length at brush spacing.
    fn quad(&mut self, p0: [f32; 2], c: [f32; 2], p1: [f32; 2], pr0: f32, pr1: f32) {
        let len = ((c[0] - p0[0]).powi(2) + (c[1] - p0[1]).powi(2)).sqrt()
            + ((p1[0] - c[0]).powi(2) + (p1[1] - c[1]).powi(2)).sqrt();
        let step = self.step();
        let n = ((len / (step * 0.5)).ceil() as i32).clamp(1, 512);
        let mut px = p0[0];
        let mut py = p0[1];
        let mut pp = pr0;
        for i in 1..=n {
            let t = i as f32 / n as f32;
            let u = 1.0 - t;
            let x = u * u * p0[0] + 2.0 * u * t * c[0] + t * t * p1[0];
            let y = u * u * p0[1] + 2.0 * u * t * c[1] + t * t * p1[1];
            let pr = pr0 + (pr1 - pr0) * t;
            let dx = x - px;
            let dy = y - py;
            let l = (dx * dx + dy * dy).sqrt();
            if l > 0.0 {
                let mut pos = self.st.carry;
                while pos <= l {
                    let f = pos / l;
                    stamp(&mut self.canvas, &self.brush, &self.sym, px + dx * f, py + dy * f, pp + (pr - pp) * f, self.st.tilt);
                    pos += step;
                }
                self.st.carry = pos - l;
            }
            px = x;
            py = y;
            pp = pr;
        }
    }

    /// Stack-based scanline flood fill on raw tile buffers. `paint` receives the 4-byte pixel.
    pub fn flood_fill<F: FnMut(&mut [u8], u32, u32)>(&mut self, sx: u32, sy: u32, tol: u8, mut paint: F) -> u32 {
        let (w, h) = (self.canvas.width, self.canvas.height);
        if sx >= w || sy >= h {
            return 0;
        }
        let seed = self.canvas.get_pixel(sx, sy);
        let mut vis = vec![0u64; (w as usize * h as usize + 63) / 64];
        let is_vis = |v: &Vec<u64>, x: u32, y: u32| {
            let i = y as usize * w as usize + x as usize;
            v[i >> 6] >> (i & 63) & 1 == 1
        };
        self.stack.clear();
        self.stack.push((sx, sy));
        let mut filled = 0u32;
        while let Some((x, y)) = self.stack.pop() {
            if is_vis(&vis, x, y) || !near(self.canvas.get_pixel(x, y), seed, tol) {
                continue;
            }
            let mut l = x;
            while l > 0 && !is_vis(&vis, l - 1, y) && near(self.canvas.get_pixel(l - 1, y), seed, tol) {
                l -= 1;
            }
            let mut r = x;
            while r + 1 < w && !is_vis(&vis, r + 1, y) && near(self.canvas.get_pixel(r + 1, y), seed, tol) {
                r += 1;
            }
            for xx in l..=r {
                let i = y as usize * w as usize + xx as usize;
                vis[i >> 6] |= 1u64 << (i & 63);
                let t = self.canvas.tile_mut(xx / 256, y / 256);
                let o = (((y % 256) * 256 + (xx % 256)) * 4) as usize;
                paint(&mut t[o..o + 4], xx, y);
            }
            filled = filled.saturating_add(r - l + 1);
            for ny in [y as i64 - 1, y as i64 + 1] {
                if ny < 0 || ny >= h as i64 {
                    continue;
                }
                let ny = ny as u32;
                let mut in_run = false;
                for xx in l..=r {
                    let ok = !is_vis(&vis, xx, ny) && near(self.canvas.get_pixel(xx, ny), seed, tol);
                    if ok && !in_run {
                        self.stack.push((xx, ny));
                    }
                    in_run = ok;
                }
            }
        }
        filled
    }

    pub fn replace_begin(&mut self, m: ColorMatcher) {
        self.job = Some(ReplaceJob { m, cursor: 0, changed: 0 });
    }

    /// Processes up to `n` tile slots; returns slots remaining (0 = finished).
    pub fn replace_step(&mut self, n: usize) -> i32 {
        let Some(job) = self.job.as_mut() else { return 0 };
        let total = self.canvas.slot_count();
        let end = (job.cursor + n).min(total);
        let m = job.m;
        let mut ch = 0u64;
        self.canvas.for_each_tile_range(job.cursor, end, |t| {
            let c = m.replace_in_tile(t);
            ch += c as u64;
            c > 0
        });
        job.cursor = end;
        job.changed += ch;
        (total - end) as i32
    }
}

// ───────────────────────── JNI ─────────────────────────

static ENGINE: Mutex<Option<Engine>> = Mutex::new(None);

#[inline]
fn with<R>(default: R, f: impl FnOnce(&mut Engine) -> R) -> R {
    let mut g = ENGINE.lock().unwrap_or_else(|e| e.into_inner());
    match g.as_mut() {
        Some(e) => f(e),
        None => default,
    }
}

#[inline]
fn argb(v: jint) -> [u8; 4] {
    [(v >> 16) as u8, (v >> 8) as u8, v as u8, (v >> 24) as u8]
}

#[inline]
fn to_argb(c: [u8; 4]) -> jint {
    ((c[3] as i32) << 24) | ((c[0] as i32) << 16) | ((c[1] as i32) << 8) | c[2] as i32
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeInit(
    mut env: JNIEnv,
    _c: JClass,
    w: jint,
    h: jint,
    spill: JString,
    budget_mb: jint,
) -> jint {
    if w <= 0 || h <= 0 {
        return -1;
    }
    let path: String = match env.get_string(&spill) {
        Ok(s) => s.into(),
        Err(_) => String::new(),
    };
    let budget = (budget_mb.max(16) as usize * 1024 * 1024) / TILE_BYTES;
    let p = if path.is_empty() { None } else { Some(path.as_str()) };
    match VirtualCanvas16K::new(w as u32, h as u32, p, budget) {
        Ok(c) => {
            let mut g = ENGINE.lock().unwrap_or_else(|e| e.into_inner());
            *g = Some(Engine::new(c));
            0
        }
        Err(e) => e,
    }
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeRelease(_env: JNIEnv, _c: JClass) {
    let mut g = ENGINE.lock().unwrap_or_else(|e| e.into_inner());
    *g = None;
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeSetViewport(
    _env: JNIEnv,
    _c: JClass,
    x0: jint,
    y0: jint,
    x1: jint,
    y1: jint,
) {
    with((), |e| e.canvas.set_viewport(x0, y0, x1, y1));
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeRender(
    env: JNIEnv,
    _c: JClass,
    out: JByteBuffer,
    ow: jint,
    oh: jint,
    x0: jfloat,
    y0: jfloat,
    scale: jfloat,
    premul: jboolean,
) -> jint {
    if ow <= 0 || oh <= 0 || scale <= 0.0 {
        return -1;
    }
    let need = ow as usize * oh as usize * 4;
    let ptr = match env.get_direct_buffer_address(&out) {
        Ok(p) => p,
        Err(_) => return -2,
    };
    let cap = env.get_direct_buffer_capacity(&out).unwrap_or(0);
    if ptr.is_null() || cap < need {
        return -3;
    }
    let buf = unsafe { std::slice::from_raw_parts_mut(ptr, need) };
    with(-4, |e| {
        e.canvas.render(buf, ow as u32, oh as u32, x0, y0, scale, premul != 0);
        0
    })
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeSetBrush(
    _env: JNIEnv,
    _c: JClass,
    size: jfloat,
    hardness: jfloat,
    opacity: jfloat,
    flow: jfloat,
    spacing: jfloat,
    press_size: jfloat,
    press_opacity: jfloat,
    tilt_size: jfloat,
    color: jint,
    mode: jint,
) {
    with((), |e| {
        e.brush = Brush {
            size: size.max(1.0),
            hardness,
            opacity,
            flow,
            spacing: spacing.clamp(0.02, 1.0),
            press_size: press_size.clamp(0.0, 1.0),
            press_opacity: press_opacity.clamp(0.0, 1.0),
            tilt_size,
            color: argb(color),
            mode: BlendMode::from_i32(mode),
        }
    });
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeSetStabilizer(_env: JNIEnv, _c: JClass, s: jfloat) {
    with((), |e| e.stab.set_strength(s));
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeSetSymmetry(
    _env: JNIEnv,
    _c: JClass,
    mode: jint,
    count: jint,
    cx: jfloat,
    cy: jfloat,
) {
    with((), |e| e.sym.set(mode.clamp(0, 5) as u8, count.clamp(2, 16) as u8, cx, cy));
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeSymmetryCount(_env: JNIEnv, _c: JClass) -> jint {
    with(1, |e| {
        let mut pts = [0u64; MAX_SYM];
        e.sym.points(0.0, 0.0, &mut pts) as jint
    })
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeMirrorPoint(
    _env: JNIEnv,
    _c: JClass,
    x: jfloat,
    y: jfloat,
    index: jint,
) -> jlong {
    with(pack(x, y) as jlong, |e| {
        let mut pts = [0u64; MAX_SYM];
        let n = e.sym.points(x, y, &mut pts);
        pts[(index.max(0) as usize).min(n - 1)] as jlong
    })
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeBeginStroke(
    _env: JNIEnv,
    _c: JClass,
    x: jfloat,
    y: jfloat,
    p: jfloat,
    tilt: jfloat,
) {
    with((), |e| e.begin_stroke(x, y, p, tilt));
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeMoveStroke(
    _env: JNIEnv,
    _c: JClass,
    x: jfloat,
    y: jfloat,
    p: jfloat,
    tilt: jfloat,
    dt: jfloat,
) {
    with((), |e| e.move_stroke(x, y, p, tilt, dt));
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeEndStroke(
    _env: JNIEnv,
    _c: JClass,
    x: jfloat,
    y: jfloat,
    p: jfloat,
) {
    with((), |e| e.end_stroke(x, y, p));
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeFloodFill(
    _env: JNIEnv,
    _c: JClass,
    x: jint,
    y: jint,
    tol: jint,
    color: jint,
) -> jint {
    if x < 0 || y < 0 {
        return 0;
    }
    let col = argb(color);
    with(0, |e| {
        e.flood_fill(x as u32, y as u32, tol.clamp(0, 255) as u8, |px, _, _| px.copy_from_slice(&col)) as jint
    })
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeFloodPattern(
    env: JNIEnv,
    _c: JClass,
    x: jint,
    y: jint,
    tol: jint,
    pattern: JByteBuffer,
    pw: jint,
    ph: jint,
) -> jint {
    if x < 0 || y < 0 || pw <= 0 || ph <= 0 {
        return 0;
    }
    let need = pw as usize * ph as usize * 4;
    let ptr = match env.get_direct_buffer_address(&pattern) {
        Ok(p) => p,
        Err(_) => return -1,
    };
    let cap = env.get_direct_buffer_capacity(&pattern).unwrap_or(0);
    if ptr.is_null() || cap < need {
        return -2;
    }
    let pat = unsafe { std::slice::from_raw_parts(ptr as *const u8, need) };
    let (pw, ph) = (pw as u32, ph as u32);
    with(0, |e| {
        // Pattern is anchored to canvas (0,0), so adjacent fills tile seamlessly.
        e.flood_fill(x as u32, y as u32, tol.clamp(0, 255) as u8, |px, cx, cy| {
            let i = (((cy % ph) * pw + (cx % pw)) * 4) as usize;
            px.copy_from_slice(&pat[i..i + 4]);
        }) as jint
    })
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativePickColor(_env: JNIEnv, _c: JClass, x: jint, y: jint) -> jint {
    if x < 0 || y < 0 {
        return 0;
    }
    with(0, |e| to_argb(e.canvas.get_pixel(x as u32, y as u32)))
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeReplaceBegin(
    _env: JNIEnv,
    _c: JClass,
    target: jint,
    new_color: jint,
    tol_h: jfloat,
    tol_s: jfloat,
    tol_l: jfloat,
) {
    with((), |e| e.replace_begin(ColorMatcher::new(argb(target), argb(new_color), tol_h, tol_s, tol_l)));
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeReplaceStep(_env: JNIEnv, _c: JClass, slots: jint) -> jint {
    with(0, |e| e.replace_step(slots.max(1) as usize))
}

#[no_mangle]
pub extern "system" fn Java_com_inkflow_lite_NativeEngine_nativeReplaceChanged(_env: JNIEnv, _c: JClass) -> jlong {
    with(0, |e| e.job.as_ref().map(|j| j.changed as jlong).unwrap_or(0))
}

#[allow(dead_code)]
const _TILE_CHECK: usize = TILE;
