package com.lite.rustchat

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    companion object {
        init {
            System.loadLibrary("rustchat")
        }
    }

    private external fun sendChatNative(
        provider: String,
        apiKey: String,
        model: String,
        customUrl: String,
        prompt: String
    ): String

    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences("rustchat_vault", MODE_PRIVATE)

        val tvHeaderTitle = findViewById<TextView>(R.id.tvHeaderTitle)
        val btnClearChat = findViewById<TextView>(R.id.btnClearChat)
        val pageChat = findViewById<View>(R.id.pageChat)
        val pageModels = findViewById<View>(R.id.pageModels)
        val pageKeys = findViewById<View>(R.id.pageKeys)
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        val scrollChat = findViewById<ScrollView>(R.id.scrollChat)
        val chatContainer = findViewById<LinearLayout>(R.id.chatContainer)
        val etPrompt = findViewById<EditText>(R.id.etPrompt)
        val btnSend = findViewById<Button>(R.id.btnSend)

        val rgProviders = findViewById<RadioGroup>(R.id.rgProviders)
        val etCustomModel = findViewById<EditText>(R.id.etCustomModel)

        val etKeyGemini = findViewById<EditText>(R.id.etKeyGemini)
        val etKeyDeepseek = findViewById<EditText>(R.id.etKeyDeepseek)
        val etKeyGroq = findViewById<EditText>(R.id.etKeyGroq)
        val etKeyOpenai = findViewById<EditText>(R.id.etKeyOpenai)
        val etCustomUrl = findViewById<EditText>(R.id.etCustomUrl)
        val btnSaveKeys = findViewById<Button>(R.id.btnSaveKeys)

        etKeyGemini.setText(prefs.getString("key_gemini", ""))
        etKeyDeepseek.setText(prefs.getString("key_deepseek", ""))
        etKeyGroq.setText(prefs.getString("key_groq", ""))
        etKeyOpenai.setText(prefs.getString("key_openai", ""))
        etCustomUrl.setText(prefs.getString("custom_url", ""))
        etCustomModel.setText(prefs.getString("custom_model", ""))

        var activeProvider = prefs.getString("provider", "gemini") ?: "gemini"
        when (activeProvider) {
            "deepseek" -> rgProviders.check(R.id.rbDeepseek)
            "groq" -> rgProviders.check(R.id.rbGroq)
            "openai" -> rgProviders.check(R.id.rbOpenai)
            "custom" -> rgProviders.check(R.id.rbCustom)
            else -> rgProviders.check(R.id.rbGemini)
        }

        fun updateHeader() {
            tvHeaderTitle.text = "RustChat • ${activeProvider.replaceFirstChar { it.uppercase() }}"
        }
        updateHeader()

        fun addBubble(text: String, isUser: Boolean) {
            val bubble = TextView(this).apply {
                this.text = text
                textSize = 14.5f
                setTextColor(if (isUser) Color.parseColor("#090D16") else Color.parseColor("#F8FAFC"))
                setPadding(36, 26, 36, 26)
                setTextIsSelectable(true)
                background = GradientDrawable().apply {
                    cornerRadius = 36f
                    setColor(if (isUser) Color.parseColor("#38BDF8") else Color.parseColor("#1E293B"))
                }
            }
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = if (isUser) Gravity.END else Gravity.START
                bottomMargin = 24
                if (isUser) marginStart = 90 else marginEnd = 90
            }
            chatContainer.addView(bubble, params)
            scrollChat.post { scrollChat.fullScroll(View.FOCUS_DOWN) }
        }

        addBubble("Halo! Mesin Rust siap. Gemini udah aktif sebagai default, tinggal masukin API Key di tab API Vault lalu mulai ngobrol.", false)

        bottomNav.setOnItemSelectedListener { item ->
            pageChat.visibility = if (item.itemId == R.id.nav_chat) View.VISIBLE else View.GONE
            pageModels.visibility = if (item.itemId == R.id.nav_models) View.VISIBLE else View.GONE
            pageKeys.visibility = if (item.itemId == R.id.nav_keys) View.VISIBLE else View.GONE
            true
        }

        rgProviders.setOnCheckedChangeListener { _, checkedId ->
            activeProvider = when (checkedId) {
                R.id.rbDeepseek -> "deepseek"
                R.id.rbGroq -> "groq"
                R.id.rbOpenai -> "openai"
                R.id.rbCustom -> "custom"
                else -> "gemini"
            }
            prefs.edit().putString("provider", activeProvider).apply()
            updateHeader()
        }

        btnSaveKeys.setOnClickListener {
            prefs.edit()
                .putString("key_gemini", etKeyGemini.text.toString())
                .putString("key_deepseek", etKeyDeepseek.text.toString())
                .putString("key_groq", etKeyGroq.text.toString())
                .putString("key_openai", etKeyOpenai.text.toString())
                .putString("custom_url", etCustomUrl.text.toString())
                .putString("custom_model", etCustomModel.text.toString())
                .apply()
            Toast.makeText(this, "API Key & pengaturan tersimpan!", Toast.LENGTH_SHORT).show()
            bottomNav.selectedItemId = R.id.nav_chat
        }

        btnClearChat.setOnClickListener {
            chatContainer.removeAllViews()
        }

        btnSend.setOnClickListener {
            val prompt = etPrompt.text.toString().trim()
            if (prompt.isEmpty()) return@setOnClickListener

            etPrompt.text.clear()
            addBubble(prompt, true)
            btnSend.isEnabled = false
            btnSend.text = "..."

            val key = when (activeProvider) {
                "gemini" -> prefs.getString("key_gemini", "") ?: ""
                "deepseek" -> prefs.getString("key_deepseek", "") ?: ""
                "groq" -> prefs.getString("key_groq", "") ?: ""
                else -> prefs.getString("key_openai", "") ?: ""
            }
            val model = etCustomModel.text.toString()
            val url = prefs.getString("custom_url", "") ?: ""

            executor.execute {
                val reply = sendChatNative(activeProvider, key, model, url, prompt)
                runOnUiThread {
                    addBubble(reply, false)
                    btnSend.isEnabled = true
                    btnSend.text = "Kirim"
                }
            }
        }
    }
}
