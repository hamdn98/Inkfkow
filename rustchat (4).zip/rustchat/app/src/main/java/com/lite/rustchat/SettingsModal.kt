package com.lite.rustchat

import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.*
import java.util.UUID

object SettingsModal {

    private const val CF_WORKER_TEMPLATE = """export default {
  async fetch(request) {
    if (request.method === "OPTIONS") {
      return new Response(null, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
          "Access-Control-Allow-Headers": "*"
        }
      });
    }
    const u = new URL(request.url);
    const target = request.headers.get("X-Target-URL") || u.searchParams.get("url");
    if (!target) return new Response("Missing url", { status: 400 });
    const headers = new Headers(request.headers);
    headers.delete("host");
    headers.delete("X-Target-URL");
    const resp = await fetch(target, {
      method: request.method,
      headers,
      body: request.method !== "GET" ? await request.text() : undefined
    });
    const out = new Response(resp.body, resp);
    out.headers.set("Access-Control-Allow-Origin", "*");
    return out;
  }
};"""

    fun show(context: Context, onChanged: () -> Unit) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val dp = context.resources.displayMetrics.density
        fun d(v: Int): Int = (v * dp).toInt()

        var ui = ProviderStore.getUiSettings(context)
        var proxy = ProviderStore.getProxySettings(context)
        val anim = ui.animationsEnabled

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(18), d(18), d(18), d(20))
            background = GradientDrawable().apply {
                cornerRadius = d(24).toFloat()
                setColor(Color.parseColor("#16181F"))
                setStroke(d(1), Color.parseColor("#282B36"))
            }
        }

        // Top Header: Icon + "Pengaturan" + tombol Close
        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(d(4), 0, d(2), d(14))
        }

        val ivGear = ImageView(context).apply {
            setImageResource(R.drawable.ic_settings)
            setColorFilter(Color.parseColor(ui.accentHex))
            layoutParams = LinearLayout.LayoutParams(d(22), d(22)).apply { marginEnd = d(8) }
        }

        val tvTitle = TextView(context).apply {
            text = "Pengaturan"
            textSize = 21f
            typeface = Typeface.SERIF
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#F8FAFC"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val btnClose = ImageView(context).apply {
            setImageResource(R.drawable.ic_close)
            setColorFilter(Color.parseColor("#9CA3AF"))
            setPadding(d(8), d(6), d(8), d(6))
            setOnClickListener { dialog.dismiss() }
        }
        AnimHelper.attachSpringPress(btnClose, anim)

        header.addView(ivGear)
        header.addView(tvTitle)
        header.addView(btnClose)
        card.addView(header)

        // Segmented Pill Tab Bar: [ API Key | Proxy | Prompt | Tampilan ]
        val tabBar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(d(4), d(4), d(4), d(4))
            background = GradientDrawable().apply {
                cornerRadius = d(50).toFloat()
                setColor(Color.parseColor("#1E2029"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = d(16) }
        }

        val tabNames = listOf("API Key", "Proxy", "Prompt", "Tampilan")
        val tabViews = mutableListOf<TextView>()

        val contentScroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                d(420)
            )
            isVerticalScrollBarEnabled = false
        }

        val tabApiContainer = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val tabProxyContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val tabPromptContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val tabTampilanContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }

        val contentWrapper = FrameLayout(context).apply {
            addView(tabApiContainer)
            addView(tabProxyContainer)
            addView(tabPromptContainer)
            addView(tabTampilanContainer)
        }
        contentScroll.addView(contentWrapper)

        fun selectTab(index: Int) {
            for (i in tabViews.indices) {
                val active = (i == index)
                tabViews[i].apply {
                    setTextColor(if (active) Color.parseColor("#F8FAFC") else Color.parseColor("#9CA3AF"))
                    setTypeface(null, if (active) Typeface.BOLD else Typeface.NORMAL)
                    background = GradientDrawable().apply {
                        cornerRadius = d(50).toFloat()
                        setColor(if (active) Color.parseColor("#2B2E3B") else Color.TRANSPARENT)
                    }
                }
            }
            val targets = listOf(tabApiContainer, tabProxyContainer, tabPromptContainer, tabTampilanContainer)
            targets.forEachIndexed { idx, v ->
                if (idx == index) {
                    v.visibility = View.VISIBLE
                    if (anim) {
                        v.alpha = 0f
                        v.animate().alpha(1f).setDuration(170).start()
                    }
                } else {
                    v.visibility = View.GONE
                }
            }
        }

        tabNames.forEachIndexed { idx, label ->
            val tvTab = TextView(context).apply {
                text = label
                textSize = 12.5f
                gravity = Gravity.CENTER
                setPadding(0, d(9), 0, d(9))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { selectTab(idx) }
            }
            AnimHelper.attachSpringPress(tvTab, anim)
            tabViews.add(tvTab)
            tabBar.addView(tvTab)
        }

        card.addView(tabBar)
        card.addView(contentScroll)

        // ==========================================
        // TAB 1: API KEY
        // ==========================================
        lateinit var renderProviderCards: () -> Unit

        fun showProviderEditorDialog(existing: ProviderProfile?) {
            val editDialog = Dialog(context)
            editDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            editDialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            val formCard = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(d(18), d(18), d(18), d(18))
                background = GradientDrawable().apply {
                    cornerRadius = d(22).toFloat()
                    setColor(Color.parseColor("#16181F"))
                    setStroke(d(1), Color.parseColor("#323644"))
                }
            }

            val titleForm = TextView(context).apply {
                text = if (existing == null) "Tambah Provider AI" else "Edit ${existing.name}"
                textSize = 17f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.parseColor("#F8FAFC"))
                setPadding(0, 0, 0, d(12))
            }
            formCard.addView(titleForm)

            val presetItems = listOf(
                "Custom (OpenAI-compatible)",
                "Google Gemini",
                "OpenRouter",
                "Claude (Anthropic)",
                "DeepSeek",
                "Groq"
            )
            val spinner = Spinner(context).apply {
                adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, presetItems)
                setBackgroundColor(Color.parseColor("#1E2029"))
                setPadding(d(8), d(8), d(8), d(8))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = d(10) }
            }

            if (existing != null) {
                val initPos = when {
                    existing.type == "gemini" -> 1
                    existing.type == "claude" -> 3
                    existing.baseUrl.contains("openrouter", true) -> 2
                    existing.baseUrl.contains("deepseek", true) -> 4
                    existing.baseUrl.contains("groq", true) -> 5
                    else -> 0
                }
                spinner.setSelection(initPos)
            }
            formCard.addView(spinner)

            fun styledInput(hintText: String, initial: String, isPassword: Boolean = false): EditText {
                return EditText(context).apply {
                    hint = hintText
                    setText(initial)
                    textSize = 13.5f
                    setTextColor(Color.parseColor("#F8FAFC"))
                    setHintTextColor(Color.parseColor("#6B7280"))
                    if (isPassword) {
                        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    }
                    setPadding(d(14), d(11), d(14), d(11))
                    background = GradientDrawable().apply {
                        cornerRadius = d(14).toFloat()
                        setColor(Color.parseColor("#1E2029"))
                        setStroke(d(1), Color.parseColor("#2B2F3C"))
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = d(10) }
                }
            }

            val etName = styledInput("Nama Provider (misal: OpenRouter, grok-4-7)", existing?.name ?: "")
            val etUrl = styledInput("Endpoint URL (https://...)", existing?.baseUrl ?: "https://openrouter.ai/api/v1/chat/completions")
            val etModel = styledInput("Nama Model (misal: gemini-2.5-flash)", existing?.model ?: "")
            val etKey = styledInput("API Key (AIza... / sk-...)", existing?.apiKey ?: "", isPassword = true)

            var firstSpin = true
            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                    if (firstSpin && existing != null) {
                        firstSpin = false
                        return
                    }
                    firstSpin = false
                    when (pos) {
                        1 -> {
                            if (etName.text.isBlank()) etName.setText("Google Gemini")
                            etUrl.setText("https://generativelanguage.googleapis.com")
                            if (etModel.text.isBlank()) etModel.setText("gemini-2.5-flash")
                        }
                        2 -> {
                            if (etName.text.isBlank()) etName.setText("OpenRouter")
                            etUrl.setText("https://openrouter.ai/api/v1/chat/completions")
                            if (etModel.text.isBlank()) etModel.setText("anthropic/claude-sonnet-4")
                        }
                        3 -> {
                            if (etName.text.isBlank()) etName.setText("Claude Sonnet")
                            etUrl.setText("https://api.anthropic.com/v1/messages")
                            if (etModel.text.isBlank()) etModel.setText("claude-sonnet-4-5")
                        }
                        4 -> {
                            if (etName.text.isBlank()) etName.setText("DeepSeek")
                            etUrl.setText("https://api.deepseek.com/chat/completions")
                            if (etModel.text.isBlank()) etModel.setText("deepseek-chat")
                        }
                        5 -> {
                            if (etName.text.isBlank()) etName.setText("Groq")
                            etUrl.setText("https://api.groq.com/openai/v1/chat/completions")
                            if (etModel.text.isBlank()) etModel.setText("llama-3.3-70b-versatile")
                        }
                        else -> {
                            if (etName.text.isBlank()) etName.setText("Custom (OpenAI-compatible)")
                        }
                    }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }

            formCard.addView(etName)
            formCard.addView(etUrl)
            formCard.addView(etModel)
            formCard.addView(etKey)

            val btnRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
                setPadding(0, d(6), 0, 0)
            }

            val btnCancel = TextView(context).apply {
                text = "Batal"
                textSize = 13.5f
                setTextColor(Color.parseColor("#9CA3AF"))
                setPadding(d(16), d(10), d(16), d(10))
                setOnClickListener { editDialog.dismiss() }
            }

            val btnSave = TextView(context).apply {
                text = "Simpan"
                textSize = 13.5f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.parseColor("#0D0E12"))
                setPadding(d(20), d(10), d(20), d(10))
                background = GradientDrawable().apply {
                    cornerRadius = d(50).toFloat()
                    setColor(Color.parseColor(ui.accentHex))
                }
                setOnClickListener {
                    val chosenType = when (spinner.selectedItemPosition) {
                        1 -> "gemini"
                        3 -> "claude"
                        else -> "openai"
                    }
                    val cleanName = etName.text.toString().trim().ifEmpty { "Provider AI" }
                    val updated = ProviderProfile(
                        id = existing?.id ?: UUID.randomUUID().toString(),
                        name = cleanName,
                        type = chosenType,
                        baseUrl = etUrl.text.toString().trim(),
                        apiKey = etKey.text.toString().trim(),
                        model = etModel.text.toString().trim()
                    )
                    val list = ProviderStore.getProviders(context)
                    if (existing == null) {
                        list.add(updated)
                        ProviderStore.saveProviders(context, list)
                        ProviderStore.setActiveId(context, updated.id)
                    } else {
                        val idx = list.indexOfFirst { it.id == existing.id }
                        if (idx >= 0) list[idx] = updated else list.add(updated)
                        ProviderStore.saveProviders(context, list)
                    }
                    renderProviderCards()
                    onChanged()
                    editDialog.dismiss()
                }
            }

            btnRow.addView(btnCancel)
            btnRow.addView(btnSave)
            formCard.addView(btnRow)

            editDialog.setContentView(formCard)
            editDialog.window?.setLayout(
                (context.resources.displayMetrics.widthPixels * 0.90).toInt(),
                WindowManager.LayoutParams.WRAP_CONTENT
            )
            editDialog.show()
            AnimHelper.animatePopIn(formCard, anim)
        }

        renderProviderCards = {
            tabApiContainer.removeAllViews()
            val list = ProviderStore.getProviders(context)
            val active = ProviderStore.getActiveProvider(context)
            val accentColor = Color.parseColor(ui.accentHex)

            for (item in list) {
                val isActive = (item.id == active.id)

                val itemCard = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(d(14), d(13), d(12), d(13))
                    background = GradientDrawable().apply {
                        cornerRadius = d(16).toFloat()
                        setColor(Color.parseColor("#1E2029"))
                        if (isActive) {
                            setStroke(d(2), accentColor)
                        } else {
                            setStroke(d(1), Color.parseColor("#262934"))
                        }
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = d(10) }
                }
                AnimHelper.attachSpringPress(itemCard, anim)

                itemCard.setOnClickListener {
                    ProviderStore.setActiveId(context, item.id)
                    renderProviderCards()
                    onChanged()
                }

                val leftCol = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginEnd = d(8)
                    }
                }

                val titleLine = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }

                val tvName = TextView(context).apply {
                    text = item.name
                    textSize = 14.5f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(Color.parseColor("#F8FAFC"))
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                }
                titleLine.addView(tvName)

                if (isActive) {
                    val tvAktif = TextView(context).apply {
                        text = "AKTIF"
                        textSize = 10f
                        setTypeface(null, Typeface.BOLD)
                        setTextColor(accentColor)
                        setPadding(d(8), 0, 0, 0)
                    }
                    titleLine.addView(tvAktif)
                }

                val tvSub = TextView(context).apply {
                    text = item.subtitle()
                    textSize = 12f
                    setTextColor(Color.parseColor("#9CA3AF"))
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    setPadding(0, d(3), 0, 0)
                }

                leftCol.addView(titleLine)
                leftCol.addView(tvSub)
                itemCard.addView(leftCol)

                val btnEdit = ImageView(context).apply {
                    setImageResource(R.drawable.ic_edit)
                    setColorFilter(Color.parseColor("#E5E7EB"))
                    setPadding(d(8), d(8), d(8), d(8))
                    background = GradientDrawable().apply {
                        cornerRadius = d(50).toFloat()
                        setColor(Color.parseColor("#2A2D39"))
                    }
                    layoutParams = LinearLayout.LayoutParams(d(32), d(32)).apply { marginEnd = d(6) }
                    setOnClickListener {
                        showProviderEditorDialog(item)
                    }
                }
                AnimHelper.attachSpringPress(btnEdit, anim)

                val btnDel = ImageView(context).apply {
                    setImageResource(R.drawable.ic_delete)
                    setColorFilter(Color.parseColor("#F87171"))
                    setPadding(d(8), d(8), d(8), d(8))
                    background = GradientDrawable().apply {
                        cornerRadius = d(50).toFloat()
                        setColor(Color.parseColor("#2A2D39"))
                    }
                    layoutParams = LinearLayout.LayoutParams(d(32), d(32))
                    setOnClickListener {
                        val currentList = ProviderStore.getProviders(context)
                        if (currentList.size <= 1) {
                            Toast.makeText(context, "Minimal sisakan 1 provider ya", Toast.LENGTH_SHORT).show()
                            return@setOnClickListener
                        }
                        AlertDialog.Builder(context)
                            .setTitle("Hapus ${item.name}?")
                            .setMessage("Konfigurasi & API key untuk provider ini akan dihapus.")
                            .setPositiveButton("Hapus") { _, _ ->
                                currentList.removeAll { it.id == item.id }
                                ProviderStore.saveProviders(context, currentList)
                                renderProviderCards()
                                onChanged()
                            }
                            .setNegativeButton("Batal", null)
                            .show()
                    }
                }
                AnimHelper.attachSpringPress(btnDel, anim)

                itemCard.addView(btnEdit)
                itemCard.addView(btnDel)
                tabApiContainer.addView(itemCard)
            }

            val btnAdd = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                setPadding(0, d(12), 0, d(12))
                background = GradientDrawable().apply {
                    cornerRadius = d(50).toFloat()
                    setColor(Color.parseColor("#1B1D26"))
                    setStroke(d(1), Color.parseColor("#2F3342"))
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = d(4) }
                setOnClickListener {
                    showProviderEditorDialog(null)
                }
            }
            val ivAdd = ImageView(context).apply {
                setImageResource(R.drawable.ic_new_chat)
                setColorFilter(Color.parseColor("#F8FAFC"))
                layoutParams = LinearLayout.LayoutParams(d(18), d(18)).apply { marginEnd = d(6) }
            }
            val tvAdd = TextView(context).apply {
                text = "Tambah provider"
                textSize = 14f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.parseColor("#F8FAFC"))
            }
            btnAdd.addView(ivAdd)
            btnAdd.addView(tvAdd)
            AnimHelper.attachSpringPress(btnAdd, anim)
            tabApiContainer.addView(btnAdd)
        }
        renderProviderCards()

        // ==========================================
        // TAB 2: PROXY (Anti-CORS Relay + ON/OFF)
        // ==========================================
        val proxyCard = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(14), d(14), d(14), d(14))
            background = GradientDrawable().apply {
                cornerRadius = d(16).toFloat()
                setColor(Color.parseColor("#1E2029"))
                setStroke(d(1), Color.parseColor("#262934"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = d(12) }
        }

        val proxyHeadRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val ivShield = ImageView(context).apply {
            setImageResource(R.drawable.ic_shield)
            setColorFilter(Color.parseColor(ui.accentHex))
            layoutParams = LinearLayout.LayoutParams(d(20), d(20)).apply { marginEnd = d(8) }
        }

        val swProxy = Switch(context).apply {
            text = if (proxy.enabled) "Proxy Anti-CORS: ON" else "Proxy Anti-CORS: OFF"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(if (proxy.enabled) Color.parseColor(ui.accentHex) else Color.parseColor("#F8FAFC"))
            isChecked = proxy.enabled
            thumbTintList = ColorStateList.valueOf(Color.parseColor(ui.accentHex))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        proxyHeadRow.addView(ivShield)
        proxyHeadRow.addView(swProxy)

        val tvProxyHint = TextView(context).apply {
            text = "Melewatkan request AI lewat Cloudflare Worker / Proxy CORS agar aman dari blokir lintas domain. Matikan (OFF) jika ingin koneksi langsung."
            textSize = 12f
            setTextColor(Color.parseColor("#9CA3AF"))
            setPadding(0, d(6), 0, d(12))
        }

        val etProxyUrl = EditText(context).apply {
            hint = "URL Proxy (contoh: https://proxy.kamu.workers.dev)"
            setText(proxy.proxyUrl)
            textSize = 13.5f
            setTextColor(Color.parseColor("#F8FAFC"))
            setHintTextColor(Color.parseColor("#6B7280"))
            setPadding(d(14), d(11), d(14), d(11))
            background = GradientDrawable().apply {
                cornerRadius = d(14).toFloat()
                setColor(Color.parseColor("#16181F"))
                setStroke(d(1), Color.parseColor("#2B2F3C"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = d(12) }
        }

        val tvModeLabel = TextView(context).apply {
            text = "Format Routing Proxy"
            textSize = 12.5f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#E5E7EB"))
            setPadding(0, 0, 0, d(6))
        }

        val rgProxyMode = RadioGroup(context).apply {
            orientation = RadioGroup.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = d(10) }
        }
        val proxyModes = listOf(
            Triple("query", 7101, "Query Parameter (?url=target)"),
            Triple("header", 7102, "Header Relay (X-Target-URL)"),
            Triple("prefix", 7103, "Path Prefix (proxy/target)")
        )
        for ((mKey, mId, mLabel) in proxyModes) {
            val rb = RadioButton(context).apply {
                id = mId
                text = mLabel
                textSize = 13f
                setTextColor(Color.parseColor("#E5E7EB"))
                buttonTintList = ColorStateList.valueOf(Color.parseColor(ui.accentHex))
            }
            rgProxyMode.addView(rb)
            if (proxy.mode == mKey) rgProxyMode.check(mId)
        }

        swProxy.setOnCheckedChangeListener { _, isChecked ->
            swProxy.text = if (isChecked) "Proxy Anti-CORS: ON" else "Proxy Anti-CORS: OFF"
            swProxy.setTextColor(if (isChecked) Color.parseColor(ui.accentHex) else Color.parseColor("#F8FAFC"))
        }

        proxyCard.addView(proxyHeadRow)
        proxyCard.addView(tvProxyHint)
        proxyCard.addView(etProxyUrl)
        proxyCard.addView(tvModeLabel)
        proxyCard.addView(rgProxyMode)

        val btnSaveProxy = TextView(context).apply {
            text = "Simpan Pengaturan Proxy"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#0D0E12"))
            gravity = Gravity.CENTER
            setPadding(0, d(12), 0, d(12))
            background = GradientDrawable().apply {
                cornerRadius = d(50).toFloat()
                setColor(Color.parseColor(ui.accentHex))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = d(10) }
            setOnClickListener {
                val chosenMode = when (rgProxyMode.checkedRadioButtonId) {
                    7102 -> "header"
                    7103 -> "prefix"
                    else -> "query"
                }
                val urlInput = etProxyUrl.text.toString().trim()
                if (swProxy.isChecked && urlInput.isEmpty()) {
                    Toast.makeText(context, "Isi URL Proxy dulu atau matikan saklar Proxy", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                proxy = ProxySettings(
                    enabled = swProxy.isChecked,
                    proxyUrl = urlInput,
                    mode = chosenMode
                )
                ProviderStore.saveProxySettings(context, proxy)
                onChanged()
                val msg = if (proxy.enabled) "Proxy diaktifkan!" else "Proxy dimatikan (koneksi langsung)"
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
        }
        AnimHelper.attachSpringPress(btnSaveProxy, anim)

        val btnCopyWorker = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, d(10), 0, d(10))
            background = GradientDrawable().apply {
                cornerRadius = d(50).toFloat()
                setColor(Color.parseColor("#1E2029"))
            }
            setOnClickListener {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("CF Worker CORS Proxy", CF_WORKER_TEMPLATE))
                Toast.makeText(context, "Script Worker disalin ke clipboard!", Toast.LENGTH_SHORT).show()
            }
        }
        val ivCopyW = ImageView(context).apply {
            setImageResource(R.drawable.ic_copy)
            setColorFilter(Color.parseColor("#93A3F8"))
            layoutParams = LinearLayout.LayoutParams(d(16), d(16)).apply { marginEnd = d(6) }
        }
        val tvCopyW = TextView(context).apply {
            text = "Salin Script Cloudflare Worker"
            textSize = 12.5f
            setTextColor(Color.parseColor("#93A3F8"))
        }
        btnCopyWorker.addView(ivCopyW)
        btnCopyWorker.addView(tvCopyW)
        AnimHelper.attachSpringPress(btnCopyWorker, anim)

        tabProxyContainer.addView(proxyCard)
        tabProxyContainer.addView(btnSaveProxy)
        tabProxyContainer.addView(btnCopyWorker)

        // ==========================================
        // TAB 3: PROMPT
        // ==========================================
        val tvPromptLabel = TextView(context).apply {
            text = "System Prompt (Instruksi Karakter AI)"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#F8FAFC"))
            setPadding(0, 0, 0, d(8))
        }
        val etSysPrompt = EditText(context).apply {
            hint = "Contoh: Jawab ringkas, santai, pakai bahasa Indonesia sehari-hari..."
            setText(ui.systemPrompt)
            textSize = 13.5f
            minLines = 5
            gravity = Gravity.TOP or Gravity.START
            setTextColor(Color.parseColor("#F8FAFC"))
            setHintTextColor(Color.parseColor("#6B7280"))
            setPadding(d(14), d(12), d(14), d(12))
            background = GradientDrawable().apply {
                cornerRadius = d(16).toFloat()
                setColor(Color.parseColor("#1E2029"))
                setStroke(d(1), Color.parseColor("#2B2F3C"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = d(12) }
        }

        val presetRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = d(14) }
        }

        val presets = listOf(
            "Santai & Ringkas" to "Jawab dengan bahasa Indonesia yang santai, akrab, langsung ke inti, tanpa basa-basi.",
            "Expert Coding" to "Kamu adalah senior software engineer. Berikan kode bersih, efisien, dan siap pakai."
        )
        for ((pLabel, pBody) in presets) {
            val chip = TextView(context).apply {
                text = "+ $pLabel"
                textSize = 11.5f
                setTextColor(Color.parseColor("#93A3F8"))
                setPadding(d(11), d(6), d(11), d(6))
                background = GradientDrawable().apply {
                    cornerRadius = d(50).toFloat()
                    setColor(Color.parseColor("#1E2029"))
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = d(8) }
                setOnClickListener { etSysPrompt.setText(pBody) }
            }
            presetRow.addView(chip)
        }

        val btnSavePrompt = TextView(context).apply {
            text = "Simpan Prompt"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#0D0E12"))
            gravity = Gravity.CENTER
            setPadding(0, d(12), 0, d(12))
            background = GradientDrawable().apply {
                cornerRadius = d(50).toFloat()
                setColor(Color.parseColor(ui.accentHex))
            }
            setOnClickListener {
                ui = ui.copy(systemPrompt = etSysPrompt.text.toString())
                ProviderStore.saveUiSettings(context, ui)
                Toast.makeText(context, "System Prompt disimpan!", Toast.LENGTH_SHORT).show()
            }
        }
        AnimHelper.attachSpringPress(btnSavePrompt, anim)

        tabPromptContainer.addView(tvPromptLabel)
        tabPromptContainer.addView(etSysPrompt)
        tabPromptContainer.addView(presetRow)
        tabPromptContainer.addView(btnSavePrompt)

        // ==========================================
        // TAB 4: TAMPILAN
        // ==========================================
        val swAnim = Switch(context).apply {
            text = "Animasi & Wave Dots Loading"
            textSize = 14f
            setTextColor(Color.parseColor("#F8FAFC"))
            isChecked = ui.animationsEnabled
            setPadding(d(4), d(8), d(4), d(14))
            thumbTintList = ColorStateList.valueOf(Color.parseColor(ui.accentHex))
        }

        val tvFontLabel = TextView(context).apply {
            text = "Ukuran Teks Chat"
            textSize = 13.5f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#F8FAFC"))
            setPadding(0, d(4), 0, d(8))
        }

        val rgFont = RadioGroup(context).apply {
            orientation = RadioGroup.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = d(14) }
        }
        val fontChoices = listOf("Kecil" to 13f, "Normal" to 14.5f, "Besar" to 16.5f)
        fontChoices.forEachIndexed { i, (label, sz) ->
            val rb = RadioButton(context).apply {
                id = 5000 + i
                text = label
                setTextColor(Color.parseColor("#E5E7EB"))
                buttonTintList = ColorStateList.valueOf(Color.parseColor(ui.accentHex))
                setPadding(0, 0, d(18), 0)
            }
            rgFont.addView(rb)
            if (kotlin.math.abs(ui.fontSizeSp - sz) < 0.5f) rgFont.check(rb.id)
        }

        val tvColorLabel = TextView(context).apply {
            text = "Warna Aksen Utama"
            textSize = 13.5f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#F8FAFC"))
            setPadding(0, d(4), 0, d(8))
        }

        val rgColor = RadioGroup(context).apply {
            orientation = RadioGroup.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = d(16) }
        }
        val colorChoices = listOf(
            "Lavender" to "#93A3F8",
            "Sky" to "#38BDF8",
            "Emerald" to "#34D399",
            "Rose" to "#FB7185"
        )
        colorChoices.forEachIndexed { i, (cName, hex) ->
            val rb = RadioButton(context).apply {
                id = 6000 + i
                text = cName
                setTextColor(Color.parseColor(hex))
                buttonTintList = ColorStateList.valueOf(Color.parseColor(hex))
                setPadding(0, 0, d(12), 0)
            }
            rgColor.addView(rb)
            if (ui.accentHex.equals(hex, ignoreCase = true)) rgColor.check(rb.id)
        }

        val btnSaveTampilan = TextView(context).apply {
            text = "Terapkan Tampilan"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#0D0E12"))
            gravity = Gravity.CENTER
            setPadding(0, d(12), 0, d(12))
            background = GradientDrawable().apply {
                cornerRadius = d(50).toFloat()
                setColor(Color.parseColor(ui.accentHex))
            }
            setOnClickListener {
                val chosenFont = when (rgFont.checkedRadioButtonId) {
                    5000 -> 13f
                    5002 -> 16.5f
                    else -> 14.5f
                }
                val chosenHex = when (rgColor.checkedRadioButtonId) {
                    6001 -> "#38BDF8"
                    6002 -> "#34D399"
                    6003 -> "#FB7185"
                    else -> "#93A3F8"
                }
                ui = ui.copy(
                    animationsEnabled = swAnim.isChecked,
                    fontSizeSp = chosenFont,
                    accentHex = chosenHex
                )
                ProviderStore.saveUiSettings(context, ui)
                renderProviderCards()
                onChanged()
                Toast.makeText(context, "Tampilan diperbarui!", Toast.LENGTH_SHORT).show()
            }
        }
        AnimHelper.attachSpringPress(btnSaveTampilan, anim)

        tabTampilanContainer.addView(swAnim)
        tabTampilanContainer.addView(tvFontLabel)
        tabTampilanContainer.addView(rgFont)
        tabTampilanContainer.addView(tvColorLabel)
        tabTampilanContainer.addView(rgColor)
        tabTampilanContainer.addView(btnSaveTampilan)

        selectTab(0)

        dialog.setContentView(card)
        dialog.window?.setLayout(
            (context.resources.displayMetrics.widthPixels * 0.92).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        dialog.show()
        AnimHelper.animatePopIn(card, anim)
    }
}
