package com.lite.rustchat

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

object AnimHelper {
    fun attachSpringPress(view: View, enabled: Boolean = true) {
        view.setOnTouchListener { v, event ->
            if (!enabled) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.animate()
                        .scaleX(0.95f)
                        .scaleY(0.95f)
                        .alpha(0.86f)
                        .setDuration(90)
                        .start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .alpha(1f)
                        .setInterpolator(OvershootInterpolator(1.7f))
                        .setDuration(190)
                        .start()
                }
            }
            false
        }
    }

    fun animatePopIn(view: View, enabled: Boolean = true) {
        if (!enabled) return
        view.alpha = 0f
        view.scaleX = 0.92f
        view.scaleY = 0.92f
        view.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setInterpolator(OvershootInterpolator(1.15f))
            .setDuration(230)
            .start()
    }

    fun animateBubbleEntry(view: View, enabled: Boolean = true) {
        if (!enabled) return
        view.alpha = 0f
        view.translationY = 20f
        view.animate()
            .alpha(1f)
            .translationY(0f)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .setDuration(220)
            .start()
    }

    /**
     * Bubble loading AI dengan animasi 3 titik melompat bergelombang (wave dots),
     * ikon AI spark berdenyut, dan teks status yang berganti halus.
     */
    fun createThinkingBubble(context: Context, accentHex: String, enabled: Boolean): View {
        val dp = context.resources.displayMetrics.density
        fun d(v: Int): Int = (v * dp).toInt()
        val accent = Color.parseColor(accentHex)

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(d(16), d(13), d(18), d(13))
            background = GradientDrawable().apply {
                cornerRadius = d(20).toFloat()
                setColor(Color.parseColor("#1E2029"))
                setStroke(d(1), Color.argb(120, Color.red(accent), Color.green(accent), Color.blue(accent)))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.START
                bottomMargin = d(12)
                marginEnd = d(36)
            }
        }

        // 1. Ikon Spark AI berdenyut
        val ivSpark = ImageView(context).apply {
            setImageResource(R.drawable.ic_spark)
            setColorFilter(accent)
            layoutParams = LinearLayout.LayoutParams(d(18), d(18)).apply {
                marginEnd = d(10)
            }
        }
        card.addView(ivSpark)

        // 2. Kontainer 3 Titik Bergerak Bergelombang
        val dotsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                d(22)
            ).apply {
                marginEnd = d(10)
            }
        }

        val dots = mutableListOf<View>()
        for (i in 0 until 3) {
            val dot = View(context).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(accent)
                }
                layoutParams = LinearLayout.LayoutParams(d(7), d(7)).apply {
                    if (i < 2) marginEnd = d(5)
                }
            }
            dots.add(dot)
            dotsRow.addView(dot)
        }
        card.addView(dotsRow)

        // 3. Teks status dinamis
        val tvStatus = TextView(context).apply {
            text = "AI lagi mikir..."
            textSize = 12.5f
            setTypeface(null, Typeface.ITALIC)
            setTextColor(Color.parseColor("#B4BCD0"))
        }
        card.addView(tvStatus)

        if (enabled) {
            val animators = mutableListOf<AnimatorSet>()

            // Animasi berdenyut pada ikon spark
            val sparkScaleX = ObjectAnimator.ofFloat(ivSpark, "scaleX", 0.88f, 1.18f).apply {
                duration = 700
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
            }
            val sparkScaleY = ObjectAnimator.ofFloat(ivSpark, "scaleY", 0.88f, 1.18f).apply {
                duration = 700
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
            }
            val sparkRot = ObjectAnimator.ofFloat(ivSpark, "rotation", -10f, 10f).apply {
                duration = 900
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
            }
            val sparkSet = AnimatorSet().apply {
                playTogether(sparkScaleX, sparkScaleY, sparkRot)
                start()
            }
            animators.add(sparkSet)

            // Animasi gelombang 3 titik (staggered bounce + scale + alpha)
            dots.forEachIndexed { idx, dot ->
                val jump = ObjectAnimator.ofFloat(dot, "translationY", 0f, -6f * dp, 0f).apply {
                    duration = 680
                    startDelay = (idx * 150).toLong()
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = AccelerateDecelerateInterpolator()
                }
                val sx = ObjectAnimator.ofFloat(dot, "scaleX", 0.85f, 1.28f, 0.85f).apply {
                    duration = 680
                    startDelay = (idx * 150).toLong()
                    repeatCount = ValueAnimator.INFINITE
                }
                val sy = ObjectAnimator.ofFloat(dot, "scaleY", 0.85f, 1.28f, 0.85f).apply {
                    duration = 680
                    startDelay = (idx * 150).toLong()
                    repeatCount = ValueAnimator.INFINITE
                }
                val al = ObjectAnimator.ofFloat(dot, "alpha", 0.45f, 1.0f, 0.45f).apply {
                    duration = 680
                    startDelay = (idx * 150).toLong()
                    repeatCount = ValueAnimator.INFINITE
                }
                val set = AnimatorSet().apply {
                    playTogether(jump, sx, sy, al)
                    start()
                }
                animators.add(set)
            }

            // Siklus teks status halus tiap 2.6 detik
            val phrases = listOf(
                "AI lagi mikir...",
                "Memproses instruksi...",
                "Menyusun jawaban..."
            )
            var step = 0
            val handler = Handler(Looper.getMainLooper())
            val ticker = object : Runnable {
                override fun run() {
                    step = (step + 1) % phrases.size
                    tvStatus.animate().alpha(0f).setDuration(150).withEndAction {
                        tvStatus.text = phrases[step]
                        tvStatus.animate().alpha(1f).setDuration(180).start()
                    }.start()
                    handler.postDelayed(this, 2600)
                }
            }
            handler.postDelayed(ticker, 2600)

            card.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                override fun onViewAttachedToWindow(v: View) {}
                override fun onViewDetachedFromWindow(v: View) {
                    handler.removeCallbacks(ticker)
                    animators.forEach { it.cancel() }
                }
            })

            animateBubbleEntry(card, true)
        }

        return card
    }
}
