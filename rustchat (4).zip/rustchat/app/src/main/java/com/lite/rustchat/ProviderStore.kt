package com.lite.rustchat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class ProviderProfile(
    val id: String,
    val name: String,
    val type: String,
    val baseUrl: String,
    val apiKey: String,
    val model: String
) {
    fun subtitle(): String {
        val typeLabel = when (type) {
            "gemini" -> "Google Gemini"
            "claude" -> "Claude (Anthropic)"
            else -> if (baseUrl.contains("openrouter", true)) "OpenRouter" else "Custom (OpenAI-compatible)"
        }
        val m = model.ifBlank {
            when (type) {
                "gemini" -> "gemini-2.5-flash"
                "claude" -> "claude-sonnet-4-5"
                else -> "gpt-4o-mini"
            }
        }
        return "$typeLabel · $m"
    }
}

data class ProxySettings(
    val enabled: Boolean = false,
    val proxyUrl: String = "",
    val mode: String = "query"
)

data class UiSettings(
    val systemPrompt: String = "",
    val fontSizeSp: Float = 14.5f,
    val accentHex: String = "#93A3F8",
    val animationsEnabled: Boolean = true
)

object ProviderStore {
    private const val PREFS_NAME = "rustchat_profiles_v1"
    private const val KEY_LIST = "provider_list"
    private const val KEY_ACTIVE_ID = "active_provider_id"
    private const val KEY_SYS_PROMPT = "system_prompt"
    private const val KEY_FONT_SIZE = "font_size_sp"
    private const val KEY_ACCENT = "accent_hex"
    private const val KEY_ANIM = "animations_enabled"

    private const val KEY_PROXY_ENABLED = "proxy_enabled"
    private const val KEY_PROXY_URL = "proxy_url"
    private const val KEY_PROXY_MODE = "proxy_mode"

    fun getProviders(context: Context): MutableList<ProviderProfile> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_LIST, null)
        if (raw.isNullOrBlank()) {
            val defaults = mutableListOf(
                ProviderProfile(
                    id = "default_gemini",
                    name = "Google Gemini",
                    type = "gemini",
                    baseUrl = "https://generativelanguage.googleapis.com",
                    apiKey = "",
                    model = "gemini-2.5-flash"
                ),
                ProviderProfile(
                    id = "default_openrouter",
                    name = "OpenRouter",
                    type = "openai",
                    baseUrl = "https://openrouter.ai/api/v1/chat/completions",
                    apiKey = "",
                    model = "anthropic/claude-sonnet-4"
                ),
                ProviderProfile(
                    id = "default_custom",
                    name = "Custom (OpenAI-compatible)",
                    type = "openai",
                    baseUrl = "https://api.deepseek.com/chat/completions",
                    apiKey = "",
                    model = "deepseek-chat"
                )
            )
            saveProviders(context, defaults)
            setActiveId(context, defaults[0].id)
            return defaults
        }

        val list = mutableListOf<ProviderProfile>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    ProviderProfile(
                        id = o.optString("id", UUID.randomUUID().toString()),
                        name = o.optString("name", "Provider"),
                        type = o.optString("type", "openai"),
                        baseUrl = o.optString("baseUrl", ""),
                        apiKey = o.optString("apiKey", ""),
                        model = o.optString("model", "")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun saveProviders(context: Context, list: List<ProviderProfile>) {
        val arr = JSONArray()
        for (p in list) {
            val o = JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("type", p.type)
                put("baseUrl", p.baseUrl)
                put("apiKey", p.apiKey)
                put("model", p.model)
            }
            arr.put(o)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LIST, arr.toString())
            .apply()
    }

    fun getActiveProvider(context: Context): ProviderProfile {
        val list = getProviders(context)
        if (list.isEmpty()) {
            val fallback = ProviderProfile(
                id = "default_gemini",
                name = "Google Gemini",
                type = "gemini",
                baseUrl = "",
                apiKey = "",
                model = "gemini-2.5-flash"
            )
            saveProviders(context, listOf(fallback))
            setActiveId(context, fallback.id)
            return fallback
        }
        val activeId = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE_ID, list[0].id)
        return list.find { it.id == activeId } ?: list[0].also { setActiveId(context, it.id) }
    }

    fun setActiveId(context: Context, id: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ACTIVE_ID, id)
            .apply()
    }

    fun getProxySettings(context: Context): ProxySettings {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return ProxySettings(
            enabled = prefs.getBoolean(KEY_PROXY_ENABLED, false),
            proxyUrl = prefs.getString(KEY_PROXY_URL, "") ?: "",
            mode = prefs.getString(KEY_PROXY_MODE, "query") ?: "query"
        )
    }

    fun saveProxySettings(context: Context, proxy: ProxySettings) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_PROXY_ENABLED, proxy.enabled)
            .putString(KEY_PROXY_URL, proxy.proxyUrl.trim())
            .putString(KEY_PROXY_MODE, proxy.mode)
            .apply()
    }

    fun getUiSettings(context: Context): UiSettings {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return UiSettings(
            systemPrompt = prefs.getString(KEY_SYS_PROMPT, "") ?: "",
            fontSizeSp = prefs.getFloat(KEY_FONT_SIZE, 14.5f),
            accentHex = prefs.getString(KEY_ACCENT, "#93A3F8") ?: "#93A3F8",
            animationsEnabled = prefs.getBoolean(KEY_ANIM, true)
        )
    }

    fun saveUiSettings(context: Context, settings: UiSettings) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SYS_PROMPT, settings.systemPrompt)
            .putFloat(KEY_FONT_SIZE, settings.fontSizeSp)
            .putString(KEY_ACCENT, settings.accentHex)
            .putBoolean(KEY_ANIM, settings.animationsEnabled)
            .apply()
    }
}
