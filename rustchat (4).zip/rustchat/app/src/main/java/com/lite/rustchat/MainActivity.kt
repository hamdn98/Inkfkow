package com.lite.rustchat

import android.Manifest
import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.bottomsheet.BottomSheetDialog
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {

    private var attachedFileName: String = ""
    private var attachedTextContext: String = ""
    private var attachedMediaMime: String = ""
    private var attachedMediaB64: String = ""
    private var attachedRawHtml: String = ""
    private var pendingCameraUri: Uri? = null

    private lateinit var tvHeaderTitle: TextView
    private lateinit var tvHeaderSub: TextView
    private lateinit var ivBrandLogo: ImageView
    private lateinit var ivNewChatIcon: ImageView
    private lateinit var tvNewChatLabel: TextView
    private lateinit var scrollChat: ScrollView
    private lateinit var chatContainer: LinearLayout
    private lateinit var btnQuickModel: LinearLayout
    private lateinit var ivQuickModelSpark: ImageView
    private lateinit var tvQuickModelLabel: TextView
    private lateinit var btnCameraScan: ImageView
    private lateinit var btnSend: LinearLayout
    private lateinit var tvSendLabel: TextView
    private lateinit var ivSendIcon: ImageView
    private lateinit var attachmentChip: LinearLayout
    private lateinit var tvAttachmentName: TextView
    private lateinit var btnPreviewAttachHtml: LinearLayout
    private lateinit var ivPreviewAttachIcon: ImageView
    private lateinit var tvPreviewAttachLabel: TextView

    private val chatUpdateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            renderHistory(animateLast = true)
        }
    }

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            processPickedFile(uri)
        }
    }

    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success: Boolean ->
        val uri = pendingCameraUri
        if (success && uri != null) {
            processPickedFile(uri, customName = "Scan_Kamera_${System.currentTimeMillis() % 10000}.jpg")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    200
                )
            }
        }

        ivBrandLogo = findViewById(R.id.ivBrandLogo)
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle)
        tvHeaderSub = findViewById(R.id.tvHeaderSub)
        val btnNewChat = findViewById<LinearLayout>(R.id.btnNewChat)
        ivNewChatIcon = findViewById(R.id.ivNewChatIcon)
        tvNewChatLabel = findViewById(R.id.tvNewChatLabel)
        val btnHistory = findViewById<LinearLayout>(R.id.btnHistory)
        val btnOpenSettings = findViewById<ImageView>(R.id.btnOpenSettings)

        scrollChat = findViewById(R.id.scrollChat)
        chatContainer = findViewById(R.id.chatContainer)
        val chatInputCard = findViewById<LinearLayout>(R.id.chatInputCard)
        attachmentChip = findViewById(R.id.attachmentChip)
        tvAttachmentName = findViewById(R.id.tvAttachmentName)
        btnPreviewAttachHtml = findViewById(R.id.btnPreviewAttachHtml)
        ivPreviewAttachIcon = findViewById(R.id.ivPreviewAttachIcon)
        tvPreviewAttachLabel = findViewById(R.id.tvPreviewAttachLabel)
        val btnRemoveAttach = findViewById<ImageView>(R.id.btnRemoveAttach)

        val etPrompt = findViewById<EditText>(R.id.etPrompt)
        val btnAttach = findViewById<ImageView>(R.id.btnAttach)
        btnCameraScan = findViewById(R.id.btnCameraScan)
        btnQuickModel = findViewById(R.id.btnQuickModel)
        ivQuickModelSpark = findViewById(R.id.ivQuickModelSpark)
        tvQuickModelLabel = findViewById(R.id.tvQuickModelLabel)
        btnSend = findViewById(R.id.btnSend)
        tvSendLabel = findViewById(R.id.tvSendLabel)
        ivSendIcon = findViewById(R.id.ivSendIcon)

        chatInputCard.background = GradientDrawable().apply {
            cornerRadius = 42f
            setColor(Color.parseColor("#16181F"))
            setStroke(2, Color.parseColor("#262934"))
        }
        btnQuickModel.background = GradientDrawable().apply {
            cornerRadius = 50f
            setColor(Color.parseColor("#1E2029"))
        }
        btnAttach.background = GradientDrawable().apply {
            cornerRadius = 50f
            setColor(Color.parseColor("#1E2029"))
        }
        btnCameraScan.background = GradientDrawable().apply {
            cornerRadius = 50f
            setColor(Color.parseColor("#1E2029"))
        }
        btnNewChat.background = GradientDrawable().apply {
            cornerRadius = 50f
            setColor(Color.parseColor("#1E2029"))
        }
        btnHistory.background = GradientDrawable().apply {
            cornerRadius = 50f
            setColor(Color.parseColor("#1E2029"))
        }
        btnOpenSettings.background = GradientDrawable().apply {
            cornerRadius = 50f
            setColor(Color.parseColor("#1E2029"))
        }
        attachmentChip.background = GradientDrawable().apply {
            cornerRadius = 24f
            setColor(Color.parseColor("#1E2029"))
        }

        fun applyThemeAndProviderUI() {
            val active = ProviderStore.getActiveProvider(this)
            val ui = ProviderStore.getUiSettings(this)
            val proxy = ProviderStore.getProxySettings(this)
            val accent = Color.parseColor(ui.accentHex)

            val proxyTag = if (proxy.enabled) " · Proxy ON" else ""
            ivBrandLogo.setColorFilter(accent)
            tvHeaderSub.text = active.subtitle() + proxyTag
            tvHeaderSub.setTextColor(accent)

            ivNewChatIcon.setColorFilter(accent)
            tvNewChatLabel.setTextColor(accent)
            btnCameraScan.setColorFilter(accent)

            ivQuickModelSpark.setColorFilter(accent)
            tvQuickModelLabel.text = "${active.name} ▾"
            tvQuickModelLabel.setTextColor(accent)

            ivPreviewAttachIcon.setColorFilter(accent)
            tvPreviewAttachLabel.setTextColor(accent)

            btnSend.background = GradientDrawable().apply {
                cornerRadius = 50f
                setColor(accent)
            }

            val anim = ui.animationsEnabled
            AnimHelper.attachSpringPress(btnNewChat, anim)
            AnimHelper.attachSpringPress(btnHistory, anim)
            AnimHelper.attachSpringPress(btnOpenSettings, anim)
            AnimHelper.attachSpringPress(btnAttach, anim)
            AnimHelper.attachSpringPress(btnCameraScan, anim)
            AnimHelper.attachSpringPress(btnQuickModel, anim)
            AnimHelper.attachSpringPress(btnSend, anim)
        }
        applyThemeAndProviderUI()

        // Tombol New Chat
        btnNewChat.setOnClickListener {
            ChatStore.createNewSession(this)
            clearAttachment()
            renderHistory(animateLast = true)
            Toast.makeText(this, "Chat baru siap", Toast.LENGTH_SHORT).show()
        }

        // Tombol Riwayat Chat & Hapus
        btnHistory.setOnClickListener {
            HistoryModal.show(this) {
                renderHistory(animateLast = false)
            }
        }

        // Tombol Pengaturan (API Key, Proxy, Prompt, Tampilan)
        btnOpenSettings.setOnClickListener {
            SettingsModal.show(this) {
                applyThemeAndProviderUI()
                renderHistory(animateLast = false)
            }
        }

        // Tombol Lampiran File / PDF / ZIP / Galeri
        btnAttach.setOnClickListener {
            filePickerLauncher.launch(arrayOf("*/*"))
        }

        // Tombol Kamera Scan Foto Langsung
        btnCameraScan.setOnClickListener {
            launchCameraScan()
        }

        btnRemoveAttach.setOnClickListener {
            clearAttachment()
        }

        btnPreviewAttachHtml.setOnClickListener {
            if (attachedRawHtml.isNotEmpty()) {
                openHtmlPreview(attachedRawHtml, attachedFileName)
            }
        }

        // Quick Switcher Provider langsung di Chatbox
        btnQuickModel.setOnClickListener {
            val ui = ProviderStore.getUiSettings(this)
            val accent = Color.parseColor(ui.accentHex)
            val providers = ProviderStore.getProviders(this)
            val active = ProviderStore.getActiveProvider(this)

            val dialog = BottomSheetDialog(this)
            val sheet = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.parseColor("#16181F"))
                setPadding(44, 38, 44, 48)
            }

            val topRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(6, 0, 6, 24)
            }

            val title = TextView(this).apply {
                text = "Pilih Provider Aktif"
                textSize = 16.5f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.parseColor("#F8FAFC"))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val btnManage = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(22, 10, 22, 10)
                background = GradientDrawable().apply {
                    cornerRadius = 50f
                    setColor(Color.parseColor("#1E2029"))
                }
                setOnClickListener {
                    dialog.dismiss()
                    SettingsModal.show(this@MainActivity) {
                        applyThemeAndProviderUI()
                        renderHistory(animateLast = false)
                    }
                }
            }
            val ivGear = ImageView(this).apply {
                setImageResource(R.drawable.ic_settings)
                setColorFilter(accent)
                layoutParams = LinearLayout.LayoutParams(36, 36).apply { marginEnd = 10 }
            }
            val tvManage = TextView(this).apply {
                text = "Kelola"
                textSize = 12.5f
                setTypeface(null, Typeface.BOLD)
                setTextColor(accent)
            }
            btnManage.addView(ivGear)
            btnManage.addView(tvManage)

            topRow.addView(title)
            topRow.addView(btnManage)
            sheet.addView(topRow)

            for (item in providers) {
                val isSelected = (item.id == active.id)
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(32, 24, 32, 24)
                    background = GradientDrawable().apply {
                        cornerRadius = 28f
                        setColor(Color.parseColor("#1E2029"))
                        if (isSelected) setStroke(3, accent)
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = 14 }
                }
                AnimHelper.attachSpringPress(row, ui.animationsEnabled)

                val textCol = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }

                val tvName = TextView(this).apply {
                    text = item.name
                    textSize = 14.5f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(if (isSelected) accent else Color.parseColor("#F8FAFC"))
                }

                val tvDesc = TextView(this).apply {
                    text = item.subtitle()
                    textSize = 12f
                    setTextColor(Color.parseColor("#9CA3AF"))
                }

                textCol.addView(tvName)
                textCol.addView(tvDesc)
                row.addView(textCol)

                if (isSelected) {
                    val checkIcon = ImageView(this).apply {
                        setImageResource(R.drawable.ic_check)
                        setColorFilter(accent)
                        layoutParams = LinearLayout.LayoutParams(44, 44)
                    }
                    row.addView(checkIcon)
                }

                row.setOnClickListener {
                    ProviderStore.setActiveId(this, item.id)
                    applyThemeAndProviderUI()
                    dialog.dismiss()
                }
                sheet.addView(row)
            }

            dialog.setContentView(sheet)
            dialog.show()
        }

        btnSend.setOnClickListener {
            val rawPrompt = etPrompt.text.toString().trim()
            if (rawPrompt.isEmpty() && attachedFileName.isEmpty()) return@setOnClickListener
            if (ChatStore.isBusy(this)) {
                Toast.makeText(this, "Tunggu balasan sebelumnya selesai ya...", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val session = ChatStore.getActiveSession(this)
            val active = ProviderStore.getActiveProvider(this)
            val ui = ProviderStore.getUiSettings(this)
            val proxy = ProviderStore.getProxySettings(this)

            val recentHistory = session.messages.takeLast(4)
            val contextPrefix = if (recentHistory.isNotEmpty()) {
                buildString {
                    append("[Konteks percakapan sebelumnya]
")
                    for (h in recentHistory) {
                        val role = if (h.isUser) "User" else "Assistant"
                        append(role).append(": ").append(h.text.take(1500)).append("
")
                    }
                    append("
[Pesan terbaru]
")
                }
            } else {
                ""
            }

            val finalPrompt = buildString {
                append(contextPrefix)
                if (rawPrompt.isNotEmpty()) append(rawPrompt)
                else append("Tolong scan dan analisis lampiran ini secara detail.")
                if (attachedTextContext.isNotEmpty()) {
                    append("

")
                    append(attachedTextContext)
                }
            }

            val userDisplay = if (rawPrompt.isNotEmpty()) rawPrompt else "Scan & analisis lampiran"
            val badgeText = if (attachedFileName.isNotEmpty()) "Lampiran: $attachedFileName" else ""

            ChatStore.appendMessageToSession(
                this,
                session.id,
                ChatMsg(userDisplay, isUser = true, badge = badgeText)
            )

            val jobJson = JSONObject().apply {
                put("sessionId", session.id)
                put("providerType", active.type)
                put("apiKey", active.apiKey)
                put("model", active.model)
                put("customUrl", active.baseUrl)
                put("systemPrompt", ui.systemPrompt)
                put("prompt", finalPrompt)
                put("mediaMime", attachedMediaMime)
                put("mediaB64", attachedMediaB64)
                put("proxyEnabled", proxy.enabled)
                put("proxyUrl", proxy.proxyUrl)
                put("proxyMode", proxy.mode)
            }

            val jobFile = File(cacheDir, "job_${System.currentTimeMillis()}.json")
            jobFile.writeText(jobJson.toString())

            etPrompt.text.clear()
            clearAttachment()
            renderHistory(animateLast = true)

            val svcIntent = Intent(this, ChatWorkerService::class.java).apply {
                putExtra(ChatWorkerService.EXTRA_JOB_PATH, jobFile.absolutePath)
            }
            ContextCompat.startForegroundService(this, svcIntent)
        }

        renderHistory(animateLast = false)
    }

    private fun launchCameraScan() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 201)
            return
        }
        try {
            val photoFile = File(cacheDir, "scan_${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", photoFile)
            pendingCameraUri = uri
            cameraLauncher.launch(uri)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka kamera: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 201 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            launchCameraScan()
        }
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            chatUpdateReceiver,
            IntentFilter(ChatWorkerService.ACTION_CHAT_UPDATED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onResume() {
        super.onResume()
        renderHistory(animateLast = false)
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(chatUpdateReceiver)
        } catch (_: Exception) {
        }
    }

    private fun clearAttachment() {
        attachedFileName = ""
        attachedTextContext = ""
        attachedMediaMime = ""
        attachedMediaB64 = ""
        attachedRawHtml = ""
        attachmentChip.visibility = View.GONE
        btnPreviewAttachHtml.visibility = View.GONE
    }

    private fun processPickedFile(uri: Uri, customName: String? = null) {
        clearAttachment()
        val fileName = customName ?: getFileName(uri)
        val mime = contentResolver.getType(uri) ?: ""
        val lower = fileName.lowercase()

        try {
            when {
                mime.startsWith("image/") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp") -> {
                    val b64 = compressImageToBase64(uri)
                    if (b64 != null) {
                        attachedFileName = fileName
                        attachedMediaMime = "image/jpeg"
                        attachedMediaB64 = b64
                        showAttachmentChip("Gambar: $fileName", showHtmlPreview = false)
                    } else {
                        Toast.makeText(this, "Gagal membaca gambar", Toast.LENGTH_SHORT).show()
                    }
                }

                lower.endsWith(".pdf") || mime == "application/pdf" -> {
                    val pdfB64 = renderPdfToBase64Image(uri)
                    if (pdfB64 != null) {
                        attachedFileName = fileName
                        attachedMediaMime = "image/jpeg"
                        attachedMediaB64 = pdfB64
                        showAttachmentChip("Dokumen PDF: $fileName", showHtmlPreview = false)
                    } else {
                        Toast.makeText(this, "Gagal merender PDF", Toast.LENGTH_SHORT).show()
                    }
                }

                mime.startsWith("video/") || lower.endsWith(".mp4") || lower.endsWith(".webm") || lower.endsWith(".mkv") -> {
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    if (bytes == null) {
                        Toast.makeText(this, "Gagal membuka video", Toast.LENGTH_SHORT).show()
                        return
                    }
                    if (bytes.size > 15 * 1024 * 1024) {
                        Toast.makeText(this, "Video maksimal 15 MB biar RAM HP aman ya", Toast.LENGTH_LONG).show()
                        return
                    }
                    attachedFileName = fileName
                    attachedMediaMime = if (mime.startsWith("video/")) mime else "video/mp4"
                    attachedMediaB64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    showAttachmentChip("Video: $fileName (${bytes.size / 1024} KB)", showHtmlPreview = false)
                }

                lower.endsWith(".zip") || mime == "application/zip" -> {
                    val extracted = extractZipSummary(uri)
                    attachedFileName = fileName
                    attachedTextContext = extracted
                    showAttachmentChip("Arsip ZIP: $fileName", showHtmlPreview = false)
                }

                else -> {
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                    val text = String(bytes, Charsets.UTF_8).take(80000)
                    attachedFileName = fileName
                    attachedTextContext = "--- File: $fileName ---
$text"
                    val isHtml = lower.endsWith(".html") || lower.endsWith(".htm") || text.contains("<html", ignoreCase = true)
                    if (isHtml) attachedRawHtml = text
                    showAttachmentChip("File: $fileName", showHtmlPreview = isHtml)
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error baca file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun renderPdfToBase64Image(uri: Uri): String? {
        val pfd = contentResolver.openFileDescriptor(uri, "r") ?: return null
        pfd.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                if (renderer.pageCount <= 0) return null
                val pagesToRender = minOf(renderer.pageCount, 2)
                val bitmaps = mutableListOf<Bitmap>()
                var totalHeight = 0
                val targetWidth = 1080

                for (i in 0 until pagesToRender) {
                    renderer.openPage(i).use { page ->
                        val scale = targetWidth.toFloat() / page.width.coerceAtLeast(1)
                        val w = targetWidth
                        val h = (page.height * scale).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        val canvas = Canvas(bmp)
                        canvas.drawColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bitmaps.add(bmp)
                        totalHeight += h
                    }
                }

                val combined = Bitmap.createBitmap(targetWidth, totalHeight, Bitmap.Config.ARGB_8888)
                val fullCanvas = Canvas(combined)
                fullCanvas.drawColor(Color.WHITE)
                var yOffset = 0f
                for (b in bitmaps) {
                    fullCanvas.drawBitmap(b, 0f, yOffset, null)
                    yOffset += b.height
                    b.recycle()
                }

                val out = ByteArrayOutputStream()
                combined.compress(Bitmap.CompressFormat.JPEG, 82, out)
                combined.recycle()
                return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            }
        }
    }

    private fun showAttachmentChip(label: String, showHtmlPreview: Boolean) {
        tvAttachmentName.text = label
        attachmentChip.visibility = View.VISIBLE
        btnPreviewAttachHtml.visibility = if (showHtmlPreview) View.VISIBLE else View.GONE
        AnimHelper.animatePopIn(attachmentChip, ProviderStore.getUiSettings(this).animationsEnabled)
    }

    private fun getFileName(uri: Uri): String {
        var name = "lampiran"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) {
                name = cursor.getString(idx) ?: name
            }
        }
        return name
    }

    private fun compressImageToBase64(uri: Uri): String? {
        val rawBytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        val orig = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size) ?: return null
        val maxDim = 1280
        val ratio = minOf(maxDim.toFloat() / orig.width, maxDim.toFloat() / orig.height, 1f)
        val scaled = if (ratio < 1f) {
            Bitmap.createScaledBitmap(
                orig,
                (orig.width * ratio).toInt().coerceAtLeast(1),
                (orig.height * ratio).toInt().coerceAtLeast(1),
                true
            )
        } else {
            orig
        }
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun extractZipSummary(uri: Uri): String {
        val sb = StringBuilder("[Isi Arsip ZIP]
")
        var totalChars = 0
        val textExts = setOf(
            "txt", "md", "html", "htm", "css", "js", "ts", "json", "xml",
            "rs", "toml", "kt", "kts", "java", "py", "c", "cpp", "h", "yml", "yaml", "sh", "sql", "csv"
        )
        contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val name = entry.name
                        val ext = name.substringAfterLast('.', "").lowercase()
                        sb.append("• ").append(name).append(" (").append(entry.size).append(" bytes)
")
                        if (ext in textExts && totalChars < 60000) {
                            val contentBytes = zis.readBytes()
                            val contentStr = String(contentBytes, Charsets.UTF_8).take(12000)
                            sb.append("--- ").append(name).append(" ---
")
                            sb.append(contentStr).append("

")
                            totalChars += contentStr.length
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
        return sb.toString()
    }

    private fun extractHtmlCode(text: String): String? {
        val fenced = Regex("```html\s*([\s\S]*?)```", RegexOption.IGNORE_CASE).find(text)
        if (fenced != null) return fenced.groupValues[1].trim()

        val lower = text.lowercase()
        val startIdx = when {
            lower.contains("<!doctype html") -> lower.indexOf("<!doctype html")
            lower.contains("<html") -> lower.indexOf("<html")
            else -> -1
        }
        if (startIdx >= 0) {
            val endIdx = lower.lastIndexOf("</html>")
            return if (endIdx > startIdx) {
                text.substring(startIdx, endIdx + 7)
            } else {
                text.substring(startIdx)
            }
        }
        return null
    }

    private fun openHtmlPreview(htmlCode: String, titleLabel: String = "Live HTML Preview") {
        val ui = ProviderStore.getUiSettings(this)
        val accent = Color.parseColor(ui.accentHex)

        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0D0E12"))
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#16181F"))
            setPadding(32, 24, 32, 24)
        }

        val tvTitle = TextView(this).apply {
            text = titleLabel
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#F8FAFC"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val webView = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
        }

        val btnReload = TextView(this).apply {
            text = "Reload"
            textSize = 12.5f
            setTextColor(accent)
            setPadding(20, 10, 20, 10)
            setOnClickListener {
                webView.loadDataWithBaseURL("https://localhost/", htmlCode, "text/html", "UTF-8", null)
            }
        }

        val btnClose = ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            setColorFilter(Color.parseColor("#F87171"))
            setPadding(16, 10, 12, 10)
            setOnClickListener { dialog.dismiss() }
        }

        topBar.addView(tvTitle)
        topBar.addView(btnReload)
        topBar.addView(btnClose)
        root.addView(topBar)
        root.addView(webView)

        dialog.setContentView(root)
        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT
        )
        dialog.show()

        webView.loadDataWithBaseURL("https://localhost/", htmlCode, "text/html", "UTF-8", null)
    }

    private fun renderHistory(animateLast: Boolean = false) {
        chatContainer.removeAllViews()
        val session = ChatStore.getActiveSession(this)
        val messages = session.messages
        val ui = ProviderStore.getUiSettings(this)

        if (messages.isEmpty()) {
            addBubbleView(
                ChatMsg(
                    "Halo! Sesi chat baru siap. Ketuk ikon kamera buat scan foto langsung, ikon klip buat PDF/ZIP/file, atau ikon gear di atas buat atur API Key & Proxy.",
                    isUser = false
                ),
                animate = animateLast
            )
        } else {
            messages.forEachIndexed { idx, msg ->
                val isLast = (idx == messages.lastIndex)
                addBubbleView(msg, animate = animateLast && isLast)
            }
        }

        val busy = ChatStore.isBusy(this)
        val busyInThisSession = busy && (ChatStore.getBusySessionId(this) == session.id)
        btnSend.isEnabled = !busy
        btnSend.alpha = if (busy) 0.55f else 1.0f
        tvSendLabel.text = if (busy) "Proses" else "Kirim"

        if (busyInThisSession) {
            val thinkingBubble = AnimHelper.createThinkingBubble(
                context = this,
                accentHex = ui.accentHex,
                enabled = ui.animationsEnabled
            )
            chatContainer.addView(thinkingBubble)
        }

        scrollChat.post { scrollChat.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addBubbleView(msg: ChatMsg, animate: Boolean): View {
        val ui = ProviderStore.getUiSettings(this)
        val accent = Color.parseColor(ui.accentHex)

        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = if (msg.isUser) Gravity.END else Gravity.START
                bottomMargin = 24
                if (msg.isUser) marginStart = 84 else marginEnd = 84
            }
        }

        if (msg.badge.isNotEmpty()) {
            val tvBadge = TextView(this).apply {
                text = msg.badge
                textSize = 11.5f
                setTextColor(accent)
                setPadding(12, 0, 12, 6)
            }
            wrapper.addView(tvBadge)
        }

        val bubble = TextView(this).apply {
            text = msg.text
            textSize = ui.fontSizeSp
            setTextColor(if (msg.isUser) Color.parseColor("#0D0E12") else Color.parseColor("#F8FAFC"))
            setPadding(34, 24, 34, 24)
            setTextIsSelectable(true)
            background = GradientDrawable().apply {
                cornerRadius = 36f
                setColor(if (msg.isUser) accent else Color.parseColor("#1E2029"))
            }
        }
        wrapper.addView(bubble)

        if (!msg.isUser) {
            val htmlCode = extractHtmlCode(msg.text)
            val actionRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8, 10, 8, 0)
            }

            val btnCopy = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(18, 8, 20, 8)
                background = GradientDrawable().apply {
                    cornerRadius = 20f
                    setColor(Color.parseColor("#16181F"))
                }
                setOnClickListener {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("RustChat", msg.text))
                    Toast.makeText(this@MainActivity, "Teks disalin", Toast.LENGTH_SHORT).show()
                }
            }
            val ivCopy = ImageView(this).apply {
                setImageResource(R.drawable.ic_copy)
                setColorFilter(Color.parseColor("#9CA3AF"))
                layoutParams = LinearLayout.LayoutParams(32, 32).apply { marginEnd = 8 }
            }
            val tvCopy = TextView(this).apply {
                text = "Salin"
                textSize = 11.5f
                setTextColor(Color.parseColor("#9CA3AF"))
            }
            btnCopy.addView(ivCopy)
            btnCopy.addView(tvCopy)
            actionRow.addView(btnCopy)

            if (htmlCode != null) {
                val btnPreview = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(20, 8, 22, 8)
                    background = GradientDrawable().apply {
                        cornerRadius = 20f
                        setColor(accent)
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { marginStart = 14 }
                    setOnClickListener {
                        openHtmlPreview(htmlCode)
                    }
                }
                val ivPlay = ImageView(this).apply {
                    setImageResource(R.drawable.ic_play)
                    setColorFilter(Color.parseColor("#0D0E12"))
                    layoutParams = LinearLayout.LayoutParams(32, 32).apply { marginEnd = 6 }
                }
                val tvPlay = TextView(this).apply {
                    text = "Preview HTML"
                    textSize = 11.5f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(Color.parseColor("#0D0E12"))
                }
                btnPreview.addView(ivPlay)
                btnPreview.addView(tvPlay)
                actionRow.addView(btnPreview)
            }

            wrapper.addView(actionRow)
        }

        chatContainer.addView(wrapper)
        if (animate) {
            AnimHelper.animateBubbleEntry(wrapper, ui.animationsEnabled)
        }
        return wrapper
    }
}
