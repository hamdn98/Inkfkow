package com.lite.rustchat

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object HistoryModal {

    fun show(context: Context, onSessionSelected: () -> Unit) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val dp = context.resources.displayMetrics.density
        fun d(v: Int): Int = (v * dp).toInt()

        val ui = ProviderStore.getUiSettings(context)
        val accent = Color.parseColor(ui.accentHex)
        val anim = ui.animationsEnabled

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(18), d(18), d(18), d(18))
            background = GradientDrawable().apply {
                cornerRadius = d(24).toFloat()
                setColor(Color.parseColor("#16181F"))
                setStroke(d(1), Color.parseColor("#282B36"))
            }
        }

        // Header dengan Icon History & Close
        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(d(4), 0, d(2), d(14))
        }

        val ivHead = ImageView(context).apply {
            setImageResource(R.drawable.ic_history)
            setColorFilter(accent)
            layoutParams = LinearLayout.LayoutParams(d(22), d(22)).apply { marginEnd = d(8) }
        }

        val tvTitle = TextView(context).apply {
            text = "Riwayat Chat"
            textSize = 20f
            typeface = Typeface.SERIF
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#F8FAFC"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val btnClose = ImageView(context).apply {
            setImageResource(R.drawable.ic_close)
            setColorFilter(Color.parseColor("#9CA3AF"))
            setPadding(d(8), d(6), d(8), d(6))
            setOnClickListener { dialog.dismiss() }
        }
        AnimHelper.attachSpringPress(btnClose, anim)

        header.addView(ivHead)
        header.addView(tvTitle)
        header.addView(btnClose)
        card.addView(header)

        // Tombol "+ Mulai Chat Baru"
        val btnNew = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, d(11), 0, d(11))
            background = GradientDrawable().apply {
                cornerRadius = d(50).toFloat()
                setColor(accent)
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = d(14) }
            setOnClickListener {
                ChatStore.createNewSession(context)
                onSessionSelected()
                dialog.dismiss()
            }
        }
        val ivNew = ImageView(context).apply {
            setImageResource(R.drawable.ic_new_chat)
            setColorFilter(Color.parseColor("#0D0E12"))
            layoutParams = LinearLayout.LayoutParams(d(18), d(18)).apply { marginEnd = d(6) }
        }
        val tvNew = TextView(context).apply {
            text = "Mulai Chat Baru"
            textSize = 13.5f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#0D0E12"))
        }
        btnNew.addView(ivNew)
        btnNew.addView(tvNew)
        AnimHelper.attachSpringPress(btnNew, anim)
        card.addView(btnNew)

        val scroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                d(360)
            )
            isVerticalScrollBarEnabled = false
        }

        val listContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(listContainer)
        card.addView(scroll)

        val sdf = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())

        fun renderList() {
            listContainer.removeAllViews()
            val sessions = ChatStore.getAllSessions(context)
            val activeId = ChatStore.getActiveSession(context).id

            if (sessions.isEmpty()) {
                val empty = TextView(context).apply {
                    text = "Belum ada riwayat percakapan."
                    textSize = 13.5f
                    setTextColor(Color.parseColor("#9CA3AF"))
                    gravity = Gravity.CENTER
                    setPadding(0, d(32), 0, d(32))
                }
                listContainer.addView(empty)
                return
            }

            for (session in sessions) {
                val isCurrent = (session.id == activeId)

                val row = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(d(14), d(12), d(12), d(12))
                    background = GradientDrawable().apply {
                        cornerRadius = d(16).toFloat()
                        setColor(Color.parseColor("#1E2029"))
                        if (isCurrent) {
                            setStroke(d(2), accent)
                        } else {
                            setStroke(d(1), Color.parseColor("#262934"))
                        }
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = d(10) }
                }
                AnimHelper.attachSpringPress(row, anim)

                row.setOnClickListener {
                    ChatStore.switchSession(context, session.id)
                    onSessionSelected()
                    dialog.dismiss()
                }

                val leftCol = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginEnd = d(8)
                    }
                }

                val topLine = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }

                val tvName = TextView(context).apply {
                    text = session.title
                    textSize = 14f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(Color.parseColor("#F8FAFC"))
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                }
                topLine.addView(tvName)

                if (isCurrent) {
                    val tvBadge = TextView(context).apply {
                        text = "AKTIF"
                        textSize = 10f
                        setTypeface(null, Typeface.BOLD)
                        setTextColor(accent)
                        setPadding(d(8), 0, 0, 0)
                    }
                    topLine.addView(tvBadge)
                }

                val metaText = "${session.messages.size} pesan · ${sdf.format(Date(session.updatedAt))}"
                val tvMeta = TextView(context).apply {
                    text = metaText
                    textSize = 11.5f
                    setTextColor(Color.parseColor("#9CA3AF"))
                    setPadding(0, d(3), 0, 0)
                }

                leftCol.addView(topLine)
                leftCol.addView(tvMeta)
                row.addView(leftCol)

                val btnDel = ImageView(context).apply {
                    setImageResource(R.drawable.ic_delete)
                    setColorFilter(Color.parseColor("#F87171"))
                    setPadding(d(9), d(9), d(9), d(9))
                    background = GradientDrawable().apply {
                        cornerRadius = d(50).toFloat()
                        setColor(Color.parseColor("#2A2D39"))
                    }
                    layoutParams = LinearLayout.LayoutParams(d(34), d(34))
                    setOnClickListener {
                        ChatStore.deleteSession(context, session.id)
                        renderList()
                        onSessionSelected()
                        Toast.makeText(context, "Riwayat dihapus", Toast.LENGTH_SHORT).show()
                    }
                }
                AnimHelper.attachSpringPress(btnDel, anim)

                row.addView(btnDel)
                listContainer.addView(row)
            }
        }
        renderList()

        val btnClearAll = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, d(11), 0, d(11))
            background = GradientDrawable().apply {
                cornerRadius = d(50).toFloat()
                setColor(Color.parseColor("#1B1D26"))
                setStroke(d(1), Color.parseColor("#2F3342"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = d(8) }
            setOnClickListener {
                AlertDialog.Builder(context)
                    .setTitle("Hapus Semua Riwayat?")
                    .setMessage("Semua percakapan yang tersimpan akan dihapus permanen.")
                    .setPositiveButton("Hapus Semua") { _, _ ->
                        ChatStore.clearAllSessions(context)
                        renderList()
                        onSessionSelected()
                        Toast.makeText(context, "Semua riwayat dibersihkan", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Batal", null)
                    .show()
            }
        }
        val ivTrashAll = ImageView(context).apply {
            setImageResource(R.drawable.ic_delete)
            setColorFilter(Color.parseColor("#F87171"))
            layoutParams = LinearLayout.LayoutParams(d(16), d(16)).apply { marginEnd = d(6) }
        }
        val tvClearAll = TextView(context).apply {
            text = "Hapus Semua Riwayat"
            textSize = 13f
            setTextColor(Color.parseColor("#F87171"))
        }
        btnClearAll.addView(ivTrashAll)
        btnClearAll.addView(tvClearAll)
        AnimHelper.attachSpringPress(btnClearAll, anim)
        card.addView(btnClearAll)

        dialog.setContentView(card)
        dialog.window?.setLayout(
            (context.resources.displayMetrics.widthPixels * 0.92).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        dialog.show()
        AnimHelper.animatePopIn(card, anim)
    }
}
