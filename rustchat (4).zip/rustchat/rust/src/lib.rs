use jni::objects::{JClass, JString};
use jni::sys::jstring;
use jni::JNIEnv;
use serde_json::{json, Value};

fn url_encode(input: &str) -> String {
    let mut out = String::with_capacity(input.len() * 3);
    for b in input.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                out.push(b as char);
            }
            _ => {
                out.push_str(&format!("%{:02X}", b));
            }
        }
    }
    out
}

fn resolve_proxy(
    target_url: &str,
    proxy_enabled: bool,
    proxy_url: &str,
    proxy_mode: &str,
) -> (String, Option<String>) {
    let p_url = proxy_url.trim();
    if !proxy_enabled || p_url.is_empty() {
        return (target_url.to_string(), None);
    }

    match proxy_mode.trim() {
        "header" => (p_url.to_string(), Some(target_url.to_string())),
        "prefix" => {
            let base = p_url.trim_end_matches('/');
            (format!("{}/{}", base, target_url), None)
        }
        _ => {
            let sep = if p_url.contains('?') { '&' } else { '?' };
            (format!("{}{}url={}", p_url, sep, url_encode(target_url)), None)
        }
    }
}

fn call_ai(
    provider_type: &str,
    api_key: &str,
    model: &str,
    custom_url: &str,
    system_prompt: &str,
    prompt: &str,
    media_mime: &str,
    media_b64: &str,
    proxy_enabled: bool,
    proxy_url: &str,
    proxy_mode: &str,
) -> Result<String, String> {
    if api_key.trim().is_empty() {
        return Err("API Key masih kosong. Buka Pengaturan -> Edit provider untuk isi API Key.".to_string());
    }

    let has_media = !media_b64.trim().is_empty() && !media_mime.trim().is_empty();
    let is_image = media_mime.starts_with("image/");
    let sys = system_prompt.trim();

    if provider_type == "gemini" {
        let m = if model.trim().is_empty() { "gemini-2.5-flash" } else { model.trim() };
        let raw_url = format!(
            "https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent?key={}",
            m,
            api_key.trim()
        );
        let (final_url, header_target) = resolve_proxy(&raw_url, proxy_enabled, proxy_url, proxy_mode);

        let parts = if has_media {
            json!([
                { "text": prompt },
                {
                    "inline_data": {
                        "mime_type": media_mime.trim(),
                        "data": media_b64.trim()
                    }
                }
            ])
        } else {
            json!([{ "text": prompt }])
        };

        let mut body = json!({
            "contents": [{ "parts": parts }]
        });

        if !sys.is_empty() {
            body["system_instruction"] = json!({
                "parts": [{ "text": sys }]
            });
        }

        let mut req = ureq::post(&final_url)
            .set("Content-Type", "application/json")
            .set("Origin", "https://rustchat.app");
        if let Some(t) = header_target {
            req = req.set("X-Target-URL", &t);
        }

        let resp = req
            .send_json(body)
            .map_err(|e| format!("Gagal konek ke Gemini: {}", e))?;

        let data: Value = resp.into_json().map_err(|e| format!("JSON error: {}", e))?;
        data["candidates"][0]["content"]["parts"][0]["text"]
            .as_str()
            .map(|s| s.to_string())
            .ok_or_else(|| format!("Respon kosong: {}", data))
    } else if provider_type == "claude" {
        if has_media && !is_image {
            return Err("Claude hanya mendukung gambar, PDF, ZIP, atau HTML/teks. Untuk video gunakan Google Gemini.".to_string());
        }

        let m = if model.trim().is_empty() { "claude-sonnet-4-5" } else { model.trim() };
        let content = if has_media && is_image {
            json!([
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": media_mime.trim(),
                        "data": media_b64.trim()
                    }
                },
                { "type": "text", "text": prompt }
            ])
        } else {
            json!(prompt)
        };

        let mut body = json!({
            "model": m,
            "max_tokens": 4096,
            "messages": [{ "role": "user", "content": content }]
        });

        if !sys.is_empty() {
            body["system"] = json!(sys);
        }

        let (final_url, header_target) = resolve_proxy(
            "https://api.anthropic.com/v1/messages",
            proxy_enabled,
            proxy_url,
            proxy_mode,
        );

        let mut req = ureq::post(&final_url)
            .set("Content-Type", "application/json")
            .set("x-api-key", api_key.trim())
            .set("anthropic-version", "2023-06-01")
            .set("Origin", "https://rustchat.app");
        if let Some(t) = header_target {
            req = req.set("X-Target-URL", &t);
        }

        let resp = req
            .send_json(body)
            .map_err(|e| format!("Gagal konek ke Claude: {}", e))?;

        let data: Value = resp.into_json().map_err(|e| format!("JSON error: {}", e))?;
        data["content"][0]["text"]
            .as_str()
            .map(|s| s.to_string())
            .ok_or_else(|| format!("Respon kosong: {}", data))
    } else {
        if has_media && !is_image {
            return Err("Provider OpenAI-compatible belum mendukung video langsung. Gunakan Google Gemini untuk video.".to_string());
        }

        let raw_url = if custom_url.trim().is_empty() {
            "https://api.openai.com/v1/chat/completions"
        } else {
            custom_url.trim()
        };

        let clean_url = raw_url.trim_end_matches('/');
        let target_endpoint = if clean_url.ends_with("/v1") {
            format!("{}/chat/completions", clean_url)
        } else {
            clean_url.to_string()
        };

        let (final_url, header_target) =
            resolve_proxy(&target_endpoint, proxy_enabled, proxy_url, proxy_mode);

        let m = if model.trim().is_empty() { "gpt-4o-mini" } else { model.trim() };
        let user_content = if has_media && is_image {
            json!([
                { "type": "text", "text": prompt },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": format!("data:{};base64,{}", media_mime.trim(), media_b64.trim())
                    }
                }
            ])
        } else {
            json!(prompt)
        };

        let mut messages = Vec::new();
        if !sys.is_empty() {
            messages.push(json!({ "role": "system", "content": sys }));
        }
        messages.push(json!({ "role": "user", "content": user_content }));

        let body = json!({
            "model": m,
            "messages": messages
        });

        let mut req = ureq::post(&final_url)
            .set("Content-Type", "application/json")
            .set("Authorization", &format!("Bearer {}", api_key.trim()))
            .set("HTTP-Referer", "https://rustchat.app")
            .set("Origin", "https://rustchat.app")
            .set("X-Title", "RustChat");
        if let Some(t) = header_target {
            req = req.set("X-Target-URL", &t);
        }

        let resp = req
            .send_json(body)
            .map_err(|e| format!("Request gagal: {}", e))?;

        let data: Value = resp.into_json().map_err(|e| format!("JSON error: {}", e))?;
        data["choices"][0]["message"]["content"]
            .as_str()
            .map(|s| s.to_string())
            .ok_or_else(|| format!("Respon kosong: {}", data))
    }
}

#[no_mangle]
pub extern "system" fn Java_com_lite_rustchat_RustEngine_sendChatNative(
    mut env: JNIEnv,
    _class: JClass,
    provider_type: JString,
    api_key: JString,
    model: JString,
    custom_url: JString,
    system_prompt: JString,
    prompt: JString,
    media_mime: JString,
    media_b64: JString,
    proxy_enabled: jni::sys::jboolean,
    proxy_url: JString,
    proxy_mode: JString,
) -> jstring {
    let pt: String = env.get_string(&provider_type).map(|s| s.into()).unwrap_or_default();
    let k: String = env.get_string(&api_key).map(|s| s.into()).unwrap_or_default();
    let m: String = env.get_string(&model).map(|s| s.into()).unwrap_or_default();
    let u: String = env.get_string(&custom_url).map(|s| s.into()).unwrap_or_default();
    let sp: String = env.get_string(&system_prompt).map(|s| s.into()).unwrap_or_default();
    let q: String = env.get_string(&prompt).map(|s| s.into()).unwrap_or_default();
    let mime: String = env.get_string(&media_mime).map(|s| s.into()).unwrap_or_default();
    let b64: String = env.get_string(&media_b64).map(|s| s.into()).unwrap_or_default();
    let p_en: bool = proxy_enabled != 0;
    let p_url: String = env.get_string(&proxy_url).map(|s| s.into()).unwrap_or_default();
    let p_mode: String = env.get_string(&proxy_mode).map(|s| s.into()).unwrap_or_default();

    let output = match call_ai(&pt, &k, &m, &u, &sp, &q, &mime, &b64, p_en, &p_url, &p_mode) {
        Ok(reply) => reply,
        Err(err) => format!("⚠️ {}", err),
    };

    env.new_string(output)
        .expect("Gagal bikin Java String")
        .into_raw()
}
