use jni::objects::{JClass, JString};
use jni::sys::jstring;
use jni::JNIEnv;
use serde_json::{json, Value};

fn call_ai(provider: &str, api_key: &str, model: &str, custom_url: &str, prompt: &str) -> Result<String, String> {
    if api_key.trim().is_empty() {
        return Err("API Key belum diisi. Buka tab API Vault dulu ya.".to_string());
    }

    if provider == "gemini" {
        let m = if model.trim().is_empty() { "gemini-2.5-flash" } else { model.trim() };
        let url = format!(
            "https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent?key={}",
            m,
            api_key.trim()
        );
        let body = json!({
            "contents": [{ "parts": [{ "text": prompt }] }]
        });

        let resp = ureq::post(&url)
            .set("Content-Type", "application/json")
            .send_json(body)
            .map_err(|e| format!("Gagal konek ke Gemini: {}", e))?;

        let data: Value = resp.into_json().map_err(|e| format!("JSON error: {}", e))?;
        data["candidates"][0]["content"]["parts"][0]["text"]
            .as_str()
            .map(|s| s.to_string())
            .ok_or_else(|| format!("Respon kosong: {}", data))
    } else {
        let (url, default_model) = match provider {
            "deepseek" => ("https://api.deepseek.com/chat/completions", "deepseek-chat"),
            "groq" => ("https://api.groq.com/openai/v1/chat/completions", "llama-3.3-70b-versatile"),
            "openai" => ("https://api.openai.com/v1/chat/completions", "gpt-4o-mini"),
            _ => (custom_url.trim(), "gpt-4o-mini"),
        };

        if url.is_empty() {
            return Err("Custom URL masih kosong.".to_string());
        }

        let m = if model.trim().is_empty() { default_model } else { model.trim() };
        let body = json!({
            "model": m,
            "messages": [{ "role": "user", "content": prompt }]
        });

        let resp = ureq::post(url)
            .set("Content-Type", "application/json")
            .set("Authorization", &format!("Bearer {}", api_key.trim()))
            .send_json(body)
            .map_err(|e| format!("Request gagal: {}", e))?;

        let data: Value = resp.into_json().map_err(|e| format!("JSON error: {}", e))?;
        data["choices"][0]["message"]["content"]
            .as_str()
            .map(|s| s.to_string())
            .ok_or_else(|| format!("Respon kosong: {}", data))
    }
}

#[no_mangle]
pub extern "system" fn Java_com_lite_rustchat_MainActivity_sendChatNative(
    mut env: JNIEnv,
    _class: JClass,
    provider: JString,
    api_key: JString,
    model: JString,
    custom_url: JString,
    prompt: JString,
) -> jstring {
    let p: String = env.get_string(&provider).map(|s| s.into()).unwrap_or_default();
    let k: String = env.get_string(&api_key).map(|s| s.into()).unwrap_or_default();
    let m: String = env.get_string(&model).map(|s| s.into()).unwrap_or_default();
    let u: String = env.get_string(&custom_url).map(|s| s.into()).unwrap_or_default();
    let q: String = env.get_string(&prompt).map(|s| s.into()).unwrap_or_default();

    let output = match call_ai(&p, &k, &m, &u, &q) {
        Ok(reply) => reply,
        Err(err) => format!("⚠️ {}", err),
    };

    env.new_string(output)
        .expect("Gagal bikin Java String")
        .into_raw()
}
